import type { Client, Disposable, Extension } from '@posthog/browser-common'
import { addEventListener, each, extend } from '@posthog/browser-common/utils/general-utils'
import {
    autocaptureCompatibleElements,
    DEFAULT_AUTOCAPTURE_IGNORE_LIST,
    elementMatchesCSSSelector,
    getClassNames,
    getDirectAndNestedSpanText,
    getElementsChainString,
    getEventTarget,
    getSafeText,
    isAngularStyleAttr,
    isSensitiveElement,
    makeSafeText,
    MAX_DOM_ANCESTOR_DEPTH,
    shouldCaptureDomEvent,
    shouldCaptureElement,
    shouldCaptureRageclick,
    shouldCaptureValue,
    splitClassString,
} from '@posthog/browser-common/utils/autocapture-utils'

import RageClick from './extensions/rageclick'
import { EventName, Properties, RemoteConfigResult } from './types'
import { AUTOCAPTURE_DISABLED_SERVER_SIDE } from './constants'
import type { AutocaptureConfig, AutocaptureConfigSource } from './autocapture-config'
import { AutocaptureExtension } from './extension-tokens'

import { isBoolean, isFunction, isNull, stripUrlHash } from '@posthog/core'
import { createLogger } from '@posthog/browser-common/utils/logger'
import { document, window } from '@posthog/browser-common/utils/globals'
import { convertToURL } from '@posthog/browser-common/utils/request-utils'
import { isElementNode, isShadowRoot, isTag, isTextNode } from '@posthog/browser-common/utils/element-utils'
import { includes } from '@posthog/core'

const COPY_AUTOCAPTURE_EVENT = '$copy_autocapture'

const logger = createLogger('[AutoCapture]')

function limitText(length: number, text: string): string {
    if (text.length > length) {
        return text.slice(0, length) + '...'
    }
    return text
}

export function getAugmentPropertiesFromElement(elem: Element): Properties {
    const shouldCaptureEl = shouldCaptureElement(elem)
    if (!shouldCaptureEl) {
        return {}
    }

    const props: Properties = {}

    each(elem.attributes, function (attr: Attr) {
        if (attr.name && attr.name.indexOf('data-ph-capture-attribute') === 0) {
            const propertyKey = attr.name.replace('data-ph-capture-attribute-', '')
            const propertyValue = attr.value
            if (propertyKey && propertyValue && shouldCaptureValue(propertyValue)) {
                props[propertyKey] = propertyValue
            }
        }
    })

    return props
}

export function previousElementSibling(el: Element): Element | null {
    if (el.previousElementSibling) {
        return el.previousElementSibling
    }
    let _el: Element | null = el
    do {
        _el = _el.previousSibling as Element | null // resolves to ChildNode->Node, which is Element's parent class
    } while (_el && !isElementNode(_el))
    return _el
}

export function getDefaultProperties(eventType: string): Properties {
    return {
        $event_type: eventType,
        $ce_version: 1,
    }
}

export function getPropertiesFromElement(
    elem: Element,
    maskAllAttributes: boolean,
    maskText: boolean,
    elementAttributeIgnorelist: string[] | undefined,
    disableCaptureUrlHashes: boolean = false
): Properties {
    const tag_name = elem.tagName.toLowerCase()
    const props: Properties = {
        tag_name: tag_name,
    }
    if (autocaptureCompatibleElements.indexOf(tag_name) > -1 && !maskText) {
        if (tag_name.toLowerCase() === 'a' || tag_name.toLowerCase() === 'button') {
            props['$el_text'] = limitText(1024, getDirectAndNestedSpanText(elem))
        } else {
            props['$el_text'] = limitText(1024, getSafeText(elem))
        }
    }

    const classes = getClassNames(elem)
    if (!maskAllAttributes && !elementAttributeIgnorelist?.includes('class') && classes.length > 0)
        props['classes'] = classes.filter(function (c) {
            return c !== ''
        })

    // capture the deny list here because this not-a-class class makes it tricky to use this.config in the function below
    each(elem.attributes, function (attr: Attr) {
        // Only capture attributes we know are safe
        if (isSensitiveElement(elem) && ['name', 'id', 'class', 'aria-label'].indexOf(attr.name) === -1) return

        if (elementAttributeIgnorelist?.includes(attr.name)) return

        if (!maskAllAttributes && shouldCaptureValue(attr.value) && !isAngularStyleAttr(attr.name)) {
            let value = attr.value
            if (attr.name === 'class') {
                // html attributes can _technically_ contain linebreaks,
                // but we're very intolerant of them in the class string,
                // so we strip them.
                value = splitClassString(value).join(' ')
            }
            props['attr__' + attr.name] = limitText(
                1024,
                attr.name === 'href' && disableCaptureUrlHashes ? stripUrlHash(value) : value
            )
        }
    })

    let nthChild = 1
    let nthOfType = 1
    let currentElem: Element | null = elem
    while ((currentElem = previousElementSibling(currentElem))) {
        nthChild++
        if (currentElem.tagName === elem.tagName) {
            nthOfType++
        }
    }
    props['nth_child'] = nthChild
    props['nth_of_type'] = nthOfType

    return props
}

export function autocapturePropertiesForElement(
    target: Element,
    {
        e,
        maskAllElementAttributes,
        maskAllText,
        elementAttributeIgnoreList,
        elementsChainAsString,
        disableCaptureUrlHashes,
    }: {
        e: Event
        maskAllElementAttributes: boolean
        maskAllText: boolean
        elementAttributeIgnoreList?: string[] | undefined
        elementsChainAsString: boolean
        disableCaptureUrlHashes: boolean
    }
): { props: Properties; explicitNoCapture?: boolean; target?: Element } {
    if (!isElementNode(target)) {
        return { props: {} }
    }

    const targetElementList: Element[] = [target]
    const seen = new Set<Node>([target])
    let curEl: Element = target
    while (curEl.parentNode && !isTag(curEl, 'body')) {
        // bail out of abnormally deep or cyclic (patched parentNode) ancestor chains
        if (targetElementList.length >= MAX_DOM_ANCESTOR_DEPTH) {
            break
        }
        if (isShadowRoot(curEl.parentNode)) {
            const host = curEl.parentNode.host
            if (seen.has(host)) {
                break
            }
            seen.add(host)
            targetElementList.push(host)
            curEl = host
            continue
        }
        if (!isElementNode(curEl.parentNode)) {
            break
        }
        if (seen.has(curEl.parentNode)) {
            break
        }
        seen.add(curEl.parentNode)
        targetElementList.push(curEl.parentNode)
        curEl = curEl.parentNode
    }

    // Keep the original path for privacy and selector checks, but attribute icon clicks
    // to their enclosing control rather than an SVG implementation detail.
    const controlIndex =
        e.type === 'click' && target.namespaceURI === 'http://www.w3.org/2000/svg'
            ? targetElementList.findIndex((el) => isTag(el, 'button') || isTag(el, 'a'))
            : -1
    if (controlIndex > 0) {
        maskAllText =
            maskAllText ||
            targetElementList
                .slice(0, controlIndex + 1)
                .some((el) => !shouldCaptureElement(el) || isSensitiveElement(el))
    }

    const elementsJson: Properties[] = []
    const autocaptureAugmentProperties: Properties = {}
    let href: string | false = false
    let explicitNoCapture = false

    each(targetElementList, (el) => {
        const shouldCaptureEl = shouldCaptureElement(el)

        // if the element or a parent element is an anchor tag
        // include the href as a property
        if (isTag(el, 'a') && !maskAllElementAttributes && !elementAttributeIgnoreList?.includes('href')) {
            const hrefAttr = el.getAttribute('href')
            href =
                shouldCaptureEl && !!hrefAttr && shouldCaptureValue(hrefAttr)
                    ? disableCaptureUrlHashes
                        ? stripUrlHash(hrefAttr)
                        : hrefAttr
                    : false
        }

        // allow users to programmatically prevent capturing of elements by adding class 'ph-no-capture'
        const classes = getClassNames(el)
        if (includes(classes, 'ph-no-capture')) {
            explicitNoCapture = true
        }

        elementsJson.push(
            getPropertiesFromElement(
                el,
                maskAllElementAttributes,
                maskAllText,
                elementAttributeIgnoreList,
                disableCaptureUrlHashes
            )
        )

        const augmentProperties = getAugmentPropertiesFromElement(el)
        each(augmentProperties, (value, key) => {
            // Elements are ordered from the target to its ancestors, so retain the closest value.
            if (!Object.prototype.hasOwnProperty.call(autocaptureAugmentProperties, key)) {
                autocaptureAugmentProperties[key] = value
            }
        })
    })

    if (explicitNoCapture) {
        return { props: {}, explicitNoCapture }
    }

    if (controlIndex > 0) {
        target = targetElementList[controlIndex]
        elementsJson.splice(0, controlIndex)
    }

    if (!maskAllText) {
        // if the element is a button or anchor tag get the span text from any
        // children and include it as/with the text property on the parent element
        if (isTag(target, 'a') || isTag(target, 'button')) {
            elementsJson[0]['$el_text'] = getDirectAndNestedSpanText(target)
        } else {
            elementsJson[0]['$el_text'] = getSafeText(target)
        }
    }

    let externalHref: string | undefined
    if (href) {
        elementsJson[0]['attr__href'] = href
        const hrefHost = convertToURL(href)?.host
        const locationHost = window?.location?.host
        if (hrefHost && locationHost && hrefHost !== locationHost) {
            externalHref = href
        }
    }

    const props = extend(
        getDefaultProperties(e.type),
        // Sending "$elements" is deprecated. Only one client on US cloud uses this.
        !elementsChainAsString ? { $elements: elementsJson } : {},
        // Always send $elements_chain, as it's needed downstream in site app filtering
        { $elements_chain: getElementsChainString(elementsJson) },
        elementsJson[0]?.['$el_text'] ? { $el_text: elementsJson[0]?.['$el_text'] } : {},
        externalHref && e.type === 'click' ? { $external_click_url: externalHref } : {},
        autocaptureAugmentProperties
    )

    return { props, target }
}

export class Autocapture implements Extension {
    readonly name = AutocaptureExtension
    _initialized: boolean = false
    _isDisabledServerSide: boolean | null = null
    _hasReceivedConfigResponse: boolean = false
    _elementSelectors: Set<string> | null
    private _elementSelectorsByOwner = new Map<object, Set<string>>()
    rageclicks: RageClick
    _elementsChainAsString = false
    private _client?: Client
    private readonly _config: AutocaptureConfig = {
        enabled: false,
        rageclick: false,
        maskAllElementAttributes: false,
        maskAllText: false,
        disableCaptureUrlHashes: false,
        remoteRequestsDisabled: false,
    }
    private _remoteConfigSubscription?: Disposable
    private _domEventHandler?: EventListener
    private _copiedTextHandler?: EventListener
    private _disposed = false
    private _pointerDown?: {
        target: Element
        excluded: boolean
        id: number
        x: number
        y: number
        released: boolean
        distinctId: string | undefined
    }
    private _pointerExpiry?: ReturnType<typeof setTimeout>

    private _clearPointer(): void {
        this._pointerDown = undefined
        clearTimeout(this._pointerExpiry)
        this._pointerExpiry = undefined
    }

    private _isExcludedPointerTarget(target: Element): boolean {
        if (!shouldCaptureElement(target)) return true

        const ignorelist = this._refreshConfig().css_selector_ignorelist ?? DEFAULT_AUTOCAPTURE_IGNORE_LIST
        const seen = new Set<Element>()
        let el: Element | null = target
        while (el) {
            if (seen.size >= MAX_DOM_ANCESTOR_DEPTH || seen.has(el)) return true
            seen.add(el)
            const current = el
            const classes = getClassNames(current)
            if (
                includes(classes, 'ph-no-capture') ||
                includes(classes, 'ph-sensitive') ||
                isSensitiveElement(current) ||
                ignorelist.some((selector) => elementMatchesCSSSelector(current, selector))
            ) {
                return true
            }
            const parent: ParentNode | null = el.parentNode
            el = isShadowRoot(parent) ? parent.host : parent && isElementNode(parent) ? parent : null
        }
        return false
    }

    private _trackPointer(e: PointerEvent): void {
        if (!this.isEnabled || e.type === 'pointercancel') {
            this._clearPointer()
            return
        }
        if (e.type === 'pointerdown') {
            this._clearPointer()
            const target = getEventTarget(e)
            if (e.isPrimary && e.button === 0 && !e.ctrlKey && target && isElementNode(target)) {
                this._pointerDown = {
                    target,
                    excluded: this._isExcludedPointerTarget(target),
                    id: e.pointerId,
                    x: e.clientX,
                    y: e.clientY,
                    released: false,
                    distinctId: this._client?.distinctId,
                }
            }
            return
        }
        const down = this._pointerDown
        if (!down) return
        if (e.pointerId !== down.id || Math.abs(e.clientX - down.x) > 5 || Math.abs(e.clientY - down.y) > 5) {
            this._clearPointer()
        } else if (e.type === 'pointerup') {
            down.released = true
            // The matching click follows pointerup. Never retain an origin for a later gesture.
            this._pointerExpiry = setTimeout(() => this._clearPointer(), 0)
        }
    }

    private _recoverClickTarget(e: PointerEvent): Element | null | undefined {
        const down = this._pointerDown
        this._clearPointer()
        const target = getEventTarget(e)
        if (
            down?.released &&
            down.target.isConnected &&
            down.distinctId === this._client?.distinctId &&
            e.pointerId === down.id &&
            (e.detail > 0 || e.pointerType === 'touch' || e.pointerType === 'pen') &&
            e.button === 0 &&
            Math.abs(e.clientX - down.x) <= 5 &&
            Math.abs(e.clientY - down.y) <= 5 &&
            target &&
            (isTag(target, 'html') || isTag(target, 'body'))
        ) {
            // DOM changes after pointerdown must not erase the origin's privacy exclusions.
            if (down.excluded) return null

            // The origin's normal checks stop at body. Recovery must also respect
            // opt-outs on the actual root hit by the click, including html.
            const ignorelist = this._refreshConfig().css_selector_ignorelist ?? DEFAULT_AUTOCAPTURE_IGNORE_LIST
            const excludedRoot = [target, document?.documentElement, document?.body].some((root) => {
                if (!root) return false
                const classes = getClassNames(root)
                return (
                    includes(classes, 'ph-no-capture') ||
                    includes(classes, 'ph-sensitive') ||
                    !shouldCaptureElement(root) ||
                    isSensitiveElement(root) ||
                    ignorelist.some((selector) => elementMatchesCSSSelector(root, selector))
                )
            })
            if (excludedRoot) return null
            return down.target
        }
        return undefined
    }

    constructor(private readonly _configSource: AutocaptureConfigSource) {
        this._configSource.refresh(this._config)
        this.rageclicks = new RageClick(this._config.rageclick)
        this._elementSelectors = null
    }

    setup(client: Client): void {
        this._compileUrlPatterns()
        this._client = client
        const subscription = client.onRemoteConfig(
            this.onRemoteConfig.bind(this) as Parameters<Client['onRemoteConfig']>[0]
        )
        if (this._disposed) {
            subscription.dispose()
            return
        }
        this._remoteConfigSubscription = subscription
        this.startIfEnabled()
    }

    dispose(): void {
        if (this._disposed) {
            return
        }
        this._disposed = true
        this._client = undefined
        this._remoteConfigSubscription?.dispose()
        this._remoteConfigSubscription = undefined
        this._elementSelectorsByOwner.clear()
        this._elementSelectors = null
        this._removeDomEventHandlers()
    }

    private _refreshConfig(): Readonly<AutocaptureConfig> {
        this._configSource.refresh(this._config)
        return this._config
    }

    private _compileUrlPatterns(): Readonly<AutocaptureConfig> {
        this._refreshConfig()
        this._config.url_allowlist = this._config.url_allowlist?.map((url) => new RegExp(url))
        this._config.url_ignorelist = this._config.url_ignorelist?.map((url) => new RegExp(url))
        return this._config
    }

    _addDomEventHandlers(): void {
        if (!this.isBrowserSupported()) {
            logger.info('Disabling Automatic Event Collection because this browser is not supported')
            return
        }

        if (!window || !document) {
            return
        }

        const handler = (this._domEventHandler = (e: Event) => {
            e = e || window?.event
            try {
                if (e.type === 'blur') {
                    this._clearPointer()
                    return
                }
                if (e.type.indexOf('pointer') === 0) {
                    this._trackPointer(e as PointerEvent)
                    return
                }
                const target = e.type === 'click' ? this._recoverClickTarget(e as PointerEvent) : undefined
                if (isNull(target)) return
                this._captureEvent(e, '$autocapture', target)
            } catch (error) {
                logger.error('Failed to capture event', error)
            }
        })

        addEventListener(window, 'blur', handler)
        addEventListener(document, 'submit', handler, { capture: true })
        addEventListener(document, 'change', handler, { capture: true })
        addEventListener(document, 'click', handler, { capture: true })
        each(['pointerdown', 'pointermove', 'pointerup', 'pointercancel'], (type) => {
            addEventListener(document!, type, handler, { capture: true })
        })

        if (this._refreshConfig().capture_copied_text) {
            const copiedTextHandler = (this._copiedTextHandler = (e: Event) => {
                e = e || window?.event
                try {
                    this._captureEvent(e, COPY_AUTOCAPTURE_EVENT)
                } catch (error) {
                    logger.error('Failed to capture clipboard event', error)
                }
            })

            addEventListener(document, 'copy', copiedTextHandler, { capture: true })
            addEventListener(document, 'cut', copiedTextHandler, { capture: true })
            addEventListener(document, 'paste', copiedTextHandler, { capture: true })
        }
    }

    private _removeDomEventHandlers(): void {
        this._clearPointer()
        if (this._domEventHandler) {
            window?.removeEventListener('blur', this._domEventHandler)
            each(['pointerdown', 'pointermove', 'pointerup', 'pointercancel'], (type) => {
                document?.removeEventListener(type, this._domEventHandler!, true)
            })
            document?.removeEventListener('submit', this._domEventHandler, true)
            document?.removeEventListener('change', this._domEventHandler, true)
            document?.removeEventListener('click', this._domEventHandler, true)
            this._domEventHandler = undefined
        }
        if (this._copiedTextHandler) {
            document?.removeEventListener('copy', this._copiedTextHandler, true)
            document?.removeEventListener('cut', this._copiedTextHandler, true)
            document?.removeEventListener('paste', this._copiedTextHandler, true)
            this._copiedTextHandler = undefined
        }
        this._initialized = false
    }

    public startIfEnabled(): void {
        if (!this.isEnabled) {
            this._clearPointer()
        }
        if (!this._disposed && this._client && this.isEnabled && !this._initialized) {
            this._addDomEventHandlers()
            this._initialized = true
        }
    }

    public onRemoteConfig(result: RemoteConfigResult): void {
        if (this._disposed) {
            return
        }
        this._hasReceivedConfigResponse = true
        if (!result.ok) {
            // Failed fetch = opt-out unknown: keep the last known persisted server
            // value instead of defaulting to enabled, so a network error cannot turn
            // autocapture on for an opted-out project. No persistence write.
            this.startIfEnabled()
            return
        }

        const response = result.config
        if (response.elementsChainAsString) {
            this._elementsChainAsString = response.elementsChainAsString
        }

        // A missing autocapture_opt_out carries no opt-out information:
        // keep the last known server value, as with a failed fetch.
        const optOut = response['autocapture_opt_out']
        if (isBoolean(optOut)) {
            this._client?.kv.set(AUTOCAPTURE_DISABLED_SERVER_SIDE, optOut)
            // store this in-memory in case persistence is disabled
            this._isDisabledServerSide = optOut
        }
        this.startIfEnabled()
    }

    public setElementSelectors(selectors: Set<string>, owner: object = this): void {
        if (this._disposed) {
            return
        }
        if (selectors.size) {
            this._elementSelectorsByOwner.set(owner, new Set(selectors))
        } else {
            this._elementSelectorsByOwner.delete(owner)
        }
        // Survey and product-tour actions can watch the same selector independently.
        const combined = new Set<string>()
        this._elementSelectorsByOwner.forEach((contribution) => {
            contribution.forEach((selector) => combined.add(selector))
        })
        this._elementSelectors = combined
    }

    public getElementSelectors(element: Element | null, additionalElement?: Element): string[] | null {
        const elementSelectors: string[] = []

        this._elementSelectors?.forEach((selector) => {
            const matchedElements = document?.querySelectorAll(selector)
            matchedElements?.forEach((matchedElement: Element) => {
                if (
                    (element === matchedElement || additionalElement === matchedElement) &&
                    !includes(elementSelectors, selector)
                ) {
                    elementSelectors.push(selector)
                }
            })
        })

        return elementSelectors
    }

    public get isEnabled(): boolean {
        if (this._disposed) {
            return false
        }
        const persistedServerDisabled = this._client?.kv.get<boolean>(AUTOCAPTURE_DISABLED_SERVER_SIDE)
        const memoryDisabled = this._isDisabledServerSide

        const config = this._refreshConfig()
        // Cached enablement may be stale. Wait for the initial config outcome unless
        // remote requests are disabled; failures still use the last known server value.
        if (!config.remoteRequestsDisabled && !this._hasReceivedConfigResponse) {
            return false
        }

        // The /flags-disabled bypass only applies while no config outcome has arrived;
        // once a response (or failure) has been seen, an unknown opt-out stays off.
        const clientConfigOnly = config.remoteRequestsDisabled && !this._hasReceivedConfigResponse
        if (isNull(memoryDisabled) && !isBoolean(persistedServerDisabled) && !clientConfigOnly) {
            // We only enable if we know that the server has not disabled it
            return false
        }

        const disabledServer = this._isDisabledServerSide ?? !!persistedServerDisabled
        const disabledClient = !config.enabled
        return !disabledClient && !disabledServer
    }

    private _captureEvent(e: Event, eventName: EventName = '$autocapture', targetOverride?: Element): boolean | void {
        if (!this.isEnabled) {
            this._clearPointer()
            return
        }

        /*** Don't mess with this code without running IE8 tests on it ***/
        let target = targetOverride || getEventTarget(e)
        if (isTextNode(target)) {
            // defeat Safari bug (see: http://www.quirksmode.org/js/events_properties.html)
            target = (target.parentNode || null) as Element | null
        }

        const config = this._compileUrlPatterns()
        if (eventName === '$autocapture' && e.type === 'click' && e instanceof MouseEvent) {
            if (
                !!config.rageclick &&
                this.rageclicks?.isRageClick(e.clientX, e.clientY, e.timeStamp || new Date().getTime())
            ) {
                if (shouldCaptureRageclick(target, config.rageclick)) {
                    this._captureEvent(e, '$rageclick', targetOverride)
                }
            }
        }

        const isClipboardAutocapture = eventName === COPY_AUTOCAPTURE_EVENT
        const eventConfig = isClipboardAutocapture ? { ...config, dom_event_allowlist: undefined } : config
        if (
            target &&
            shouldCaptureDomEvent(
                target,
                e,
                eventConfig,
                // mostly this method cares about the target element, but for clipboard events,
                // we want some of the work this check does without insisting on the target element's type
                isClipboardAutocapture,
                // we also don't want to restrict clipboard checks to clicks,
                // so we pass that knowledge in here, rather than add the logic inside the check
                isClipboardAutocapture ? ['copy', 'cut', 'paste'] : undefined,
                { config: { get_current_url: config.getCurrentUrl } }
            )
        ) {
            const {
                props,
                explicitNoCapture,
                target: attributedTarget,
            } = autocapturePropertiesForElement(target, {
                e,
                maskAllElementAttributes: config.maskAllElementAttributes,
                maskAllText: config.maskAllText,
                elementAttributeIgnoreList: config.element_attribute_ignorelist,
                elementsChainAsString: this._elementsChainAsString,
                disableCaptureUrlHashes: config.disableCaptureUrlHashes,
            })

            if (explicitNoCapture) {
                return false
            }

            const elementSelectors = this.getElementSelectors(target, attributedTarget)
            if (elementSelectors && elementSelectors.length > 0) {
                props['$element_selectors'] = elementSelectors
            }

            if (eventName === COPY_AUTOCAPTURE_EVENT) {
                const clipType = e.type || 'clipboard'

                // Don't add the contents for paste events, as usually the page emits an input change with the new value
                if (clipType !== 'paste') {
                    const selectedText = window?.getSelection()?.toString()
                    const selectedContent = makeSafeText(selectedText)
                    if (!selectedContent) {
                        return false
                    }
                    props['$selected_content'] = selectedContent
                    props['$clipboard_text_length'] = selectedText?.length ?? 0
                }
                props['$copy_type'] = clipType
            }

            this._client?.capture(eventName, props)
            return true
        }
    }

    isBrowserSupported(): boolean {
        return isFunction(document?.querySelectorAll)
    }
}
