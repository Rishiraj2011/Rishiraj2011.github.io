import { document } from '@posthog/browser-common/utils/globals'
import { assignableWindow, LazyLoadedDeadClicksAutocaptureInterface } from '../utils/globals'
import { PostHog } from '../posthog-core'
import { isNull, isNumber, isUndefined, trySafe } from '@posthog/core'
import {
    getEventTarget,
    isTextSelectionTarget,
    shouldCaptureDeadClick,
    shouldSkipDeadClick,
} from '@posthog/browser-common/utils/autocapture-utils'
import { DeadClickCandidate, DeadClicksAutoCaptureConfig, Properties } from '../types'
import { autocapturePropertiesForElement } from '../autocapture'
import { isElementInToolbar, isElementNode, isTag } from '@posthog/browser-common/utils/element-utils'
import { getNativeMutationObserverImplementation } from '@posthog/browser-common/utils/prototype-utils'
import { addEventListener } from '@posthog/browser-common/utils/general-utils'

function asCandidate(event: MouseEvent | TouchEvent, extra: Partial<DeadClickCandidate>): DeadClickCandidate | null {
    const eventTarget = getEventTarget(event)
    if (eventTarget) {
        return {
            node: eventTarget,
            originalEvent: event,
            timestamp: Date.now(),
            ...extra,
        }
    }
    return null
}

// Firefox denies property access on a node from another origin or from a realm that was torn
// down, and both a composed path and a mutation record can hand us one. A node we cannot read
// is a node we cannot inspect, so answer no instead of letting the denial escape.
function isInspectableElement(node: Node | EventTarget | null | undefined): node is Element {
    return !!trySafe(() => isElementNode(node as Node))
}

function swipeDirection(dx: number, dy: number): 'left' | 'right' | 'up' | 'down' {
    if (Math.abs(dx) >= Math.abs(dy)) {
        return dx >= 0 ? 'right' : 'left'
    }
    return dy >= 0 ? 'down' : 'up'
}

// the event name doubles as the property prefix ($dead_click_* / $dead_swipe_*)
function deadEventName(candidate: DeadClickCandidate): '$dead_click' | '$dead_swipe' {
    return candidate.type === 'swipe' ? '$dead_swipe' : '$dead_click'
}

// surfaces that respond to a gesture without anything our observers can see — a canvas or
// WebGL repaint is not a DOM mutation, and native media controls live in a closed UA shadow
// root — so a swipe over them can never be judged dead
const UNOBSERVABLE_SURFACE_SELECTOR = 'canvas,video,audio,embed,object'

// a click within this window of a visibility or window focus/blur change is treated as the click
// that woke/focused the tab (or opened a new tab/window) and suppressed rather than flagged dead.
// wider than the other thresholds because a real "tab back, then click the page" gesture has a
// human-scale gap (refocus, move the mouse, click); still short enough that a genuinely dead click
// a while after refocusing is caught.
const LIVENESS_SUPPRESSION_MS = 1000

function hasModifierKey(event: MouseEvent | TouchEvent): boolean {
    return event.ctrlKey || event.metaKey || event.altKey || event.shiftKey
}

function checkTimeout(value: number | undefined, thresholdMs: number) {
    return isNumber(value) && value >= thresholdMs
}

// a liveness transition only counts if it fired within the suppression window on one side of the
// click. this is the single definition of "in window" — it gates every recorded delay, so once a
// delay lands on a candidate `_checkClicks` can trust it is already in range.
function livenessDelayInWindow(delay: number, windowMs = LIVENESS_SUPPRESSION_MS): number | undefined {
    return delay >= 0 && delay < windowMs ? delay : undefined
}

// a liveness signal that fired shortly BEFORE the click. read once when the candidate is queued;
// only a change inside the suppression window counts, so a long-ago transition cannot affect it.
function priorLivenessDelay(
    clickTimestamp: number,
    lastSeenAt: number | undefined,
    windowMs = LIVENESS_SUPPRESSION_MS
): number | undefined {
    return isNumber(lastSeenAt) ? livenessDelayInWindow(clickTimestamp - lastSeenAt, windowMs) : undefined
}

type ObservedDeadClick = DeadClickCandidate & { selectionChangedDuringGesture?: boolean }

type MouseSelectionGesture = {
    path: EventTarget[]
    trusted: boolean
    selectionChanged: boolean
    selectionInitiallyRelated: boolean
    clickTarget?: EventTarget
    clickDetail?: number
}

// How dead-click detection works
// ================================
// A click (or swipe) is queued as a candidate, then re-examined ~1s later in `_checkClicks`. It is
// reported as a `$dead_click` only if NO liveness/suppression signal fired within its applicable
// window AND at least one timeout signal fired. In short: something-happened-fast wins
// (alive), otherwise nothing-happened-in-time loses (dead).
//
// Gate signals (checked in `_ignore` before the click is ever queued — never even a candidate):
//   - element is inside the PostHog toolbar
//   - same node clicked again within 1s (dedupe of repeated clicks)
//   - target is the <html> node or not an element
//   - target matches `css_selector_ignorelist`
//   - a modifier key is held (ctrl/meta/alt/shift) unless `capture_clicks_with_modifier_keys`
//   - (clicks only) target is an anchor — a legitimate activation; swipes are still candidates
//
// Liveness / suppression signals (any one, within its window => alive, dropped).
// These say "the click did something", so they only ever suppress; none can mark a click dead:
//   - mutation:   a DOM mutation           < mutation_threshold_ms (default 2500)
//   - scroll:     the page/an element scrolled < scroll_threshold_ms (default 100)
//   - selection:  selecting/unselecting a range or moving an editable caret during the matching
//                 mouse gesture, or < selection_change_threshold_ms (default 100) either side of the click
//   - visibility: a visibilitychange (either direction — the tab going hidden because the click
//                 opened a new tab, or becoming visible as the click woke/focused it)
//                 < LIVENESS_SUPPRESSION_MS on either side of the click
//   - focus:      a window focus/blur (a click that opened a new window/popup may only surface as
//                 the current window losing focus) < LIVENESS_SUPPRESSION_MS on either side
// selection/visibility/focus are recorded on each candidate, not read from a single shared
// timestamp when the click is checked. A pre-click selection is stored only inside its window;
// post-click changes keep the closest delay. For visibility/focus this also matters because
// hiding/blurring the tab can suspend the check until a later transition overwrites it.
//
// Timeout signals (a click with no liveness signal is dead if any one fired). Note visibility and
// focus are deliberately absent here — they are liveness-only and never mark a click dead:
//   - mutation timeout:  a mutation, but only after mutation_threshold_ms
//   - scroll timeout:    a scroll, but only after scroll_threshold_ms
//   - selection timeout: a selectionchange, but only after selection_change_threshold_ms
//   - absolute timeout:  nothing at all within mutation_threshold_ms * 1.1 (the catch-all backstop)
class LazyLoadedDeadClicksAutocapture implements LazyLoadedDeadClicksAutocaptureInterface {
    private _mutationObserver: MutationObserver | undefined
    private _observedRoots = new WeakSet<Node>()
    private _lastMutation: number | undefined
    private _lastScroll: number | undefined
    private _lastSelectionChanged: number | undefined
    private _hadSelection = false
    private _lastVisibilityChange: number | undefined
    private _lastFocusChange: number | undefined
    private _clicks: ObservedDeadClick[] = []
    private _checkClickTimer: number | undefined
    private _mouseSelection: MouseSelectionGesture | undefined
    private _mouseSelectionTimer: number | undefined
    private _touchStart: { x: number; y: number; timestamp: number } | undefined
    private _deadSwipesCaptured = 0
    private _hasUnobservableSurfaces: boolean | undefined
    private _surfacesCheckedAt: number | undefined
    private _config: Required<Omit<DeadClicksAutoCaptureConfig, 'css_selector_ignorelist'>> &
        Pick<DeadClicksAutoCaptureConfig, 'css_selector_ignorelist'>
    private _onCapture: (click: DeadClickCandidate, properties: Properties) => void

    private _defaultConfig = (defaultOnCapture: (click: DeadClickCandidate, properties: Properties) => void) => ({
        element_attribute_ignorelist: [],
        scroll_threshold_ms: 100,
        selection_change_threshold_ms: 100,
        mutation_threshold_ms: 2500,
        capture_clicks_with_modifier_keys: false,
        capture_dead_swipes: true,
        swipe_threshold_px: 30,
        max_dead_swipes_per_page_load: 10,
        __onCapture: defaultOnCapture,
    })

    private _asRequiredConfig(
        providedConfig?: DeadClicksAutoCaptureConfig
    ): Required<Omit<DeadClicksAutoCaptureConfig, 'css_selector_ignorelist'>> &
        Pick<DeadClicksAutoCaptureConfig, 'css_selector_ignorelist'> {
        const defaultConfig = this._defaultConfig(providedConfig?.__onCapture || this._captureDeadClick.bind(this))
        return {
            element_attribute_ignorelist:
                providedConfig?.element_attribute_ignorelist ?? defaultConfig.element_attribute_ignorelist,
            scroll_threshold_ms: providedConfig?.scroll_threshold_ms ?? defaultConfig.scroll_threshold_ms,
            selection_change_threshold_ms:
                providedConfig?.selection_change_threshold_ms ?? defaultConfig.selection_change_threshold_ms,
            mutation_threshold_ms: providedConfig?.mutation_threshold_ms ?? defaultConfig.mutation_threshold_ms,
            capture_clicks_with_modifier_keys:
                providedConfig?.capture_clicks_with_modifier_keys ?? defaultConfig.capture_clicks_with_modifier_keys,
            capture_dead_swipes: providedConfig?.capture_dead_swipes ?? defaultConfig.capture_dead_swipes,
            swipe_threshold_px: providedConfig?.swipe_threshold_px ?? defaultConfig.swipe_threshold_px,
            max_dead_swipes_per_page_load:
                providedConfig?.max_dead_swipes_per_page_load ?? defaultConfig.max_dead_swipes_per_page_load,
            css_selector_ignorelist: providedConfig?.css_selector_ignorelist,
            __onCapture: defaultConfig.__onCapture,
        }
    }

    constructor(
        readonly instance: PostHog,
        config?: DeadClicksAutoCaptureConfig
    ) {
        this._config = this._asRequiredConfig(config)
        this._onCapture = this._config.__onCapture
    }

    start(observerTarget: Node) {
        this._startClickObserver()
        this._startScrollObserver()
        this._startSelectionChangedObserver()
        this._startVisibilityChangeObserver()
        this._startFocusChangeObserver()
        this._startMutationObserver(observerTarget)
        if (this._config.capture_dead_swipes) {
            this._startSwipeObserver()
        }
    }

    private _startMutationObserver(observerTarget: Node) {
        if (!this._mutationObserver) {
            const NativeMutationObserver = getNativeMutationObserverImplementation(assignableWindow)
            this._mutationObserver = new NativeMutationObserver((mutations) => {
                this._onMutation(mutations)
            })
            this._observeRoot(observerTarget)
        }
    }

    // An observed subtree stops at a shadow boundary, so a click that re-renders inside a shadow
    // root looks like nothing happened. Each root we want changes from needs its own observe call.
    private _observeRoot(root: Node | null | undefined): void {
        if (!root || !this._mutationObserver) {
            return
        }
        if (this._observedRoots.has(root)) {
            return
        }
        this._mutationObserver.observe(root, {
            attributes: true,
            characterData: true,
            childList: true,
            subtree: true,
        })
        this._observedRoots.add(root)
        this._observeShadowRoots(root)
    }

    // Observe every open shadow root this node hosts or contains. Nested roots are covered
    // because each root observed here is scanned in turn. Every scanned element is added to
    // `scanned`, when given, so a caller can skip nodes an earlier scan already covered.
    private _observeShadowRoots(node: Node, scanned?: Set<Node>): void {
        if (isElementNode(node) && node.shadowRoot) {
            this._observeRoot(node.shadowRoot)
        }
        const descendants = (node as Element).querySelectorAll?.('*') ?? []
        for (let i = 0; i < descendants.length; i++) {
            scanned?.add(descendants[i])
            this._observeRoot(descendants[i].shadowRoot)
        }
    }

    // A gesture inside an open shadow root exposes that root in its composed path, so we can
    // watch the root before the application's own handlers render into it.
    private _observeGesturePath(event: Event): void {
        const path = event.composedPath?.() ?? []
        for (let i = 0; i < path.length; i++) {
            const node = path[i]
            if (isInspectableElement(node)) {
                this._observeRoot(node.shadowRoot)
            }
        }
    }

    stop() {
        this._mutationObserver?.disconnect()
        this._mutationObserver = undefined
        this._observedRoots = new WeakSet()
        assignableWindow.removeEventListener('click', this._onClick, { capture: true })
        assignableWindow.removeEventListener('mousedown', this._onMouseDown, { capture: true })
        assignableWindow.removeEventListener('mouseup', this._onMouseUp, { capture: true })
        assignableWindow.removeEventListener('mouseout', this._onMouseOut, { capture: true })
        assignableWindow.removeEventListener('dragstart', this._clearMouseSelection, { capture: true })
        assignableWindow.removeEventListener('pointercancel', this._clearMouseSelection, { capture: true })
        assignableWindow.removeEventListener('blur', this._clearMouseSelection)
        this._clearMouseSelection()
        assignableWindow.removeEventListener('scroll', this._onScroll, { capture: true })
        document?.removeEventListener('selectionchange', this._onSelectionChange)
        assignableWindow.removeEventListener('touchstart', this._onTouchStart, { capture: true })
        assignableWindow.removeEventListener('touchend', this._onTouchEnd, { capture: true })
        assignableWindow.removeEventListener('touchcancel', this._onTouchCancel, { capture: true })
        document?.removeEventListener('visibilitychange', this._onVisibilityChange)
        assignableWindow.removeEventListener('blur', this._onFocusChange)
        assignableWindow.removeEventListener('focus', this._onFocusChange)
        // so a gesture in flight when we stopped can't pair with a touchend after a restart
        this._touchStart = undefined
    }

    private _onMutation(mutations: MutationRecord[]): void {
        // every scan in this batch reads the DOM as it is now, so a node an earlier scan visited
        // needs no scan of its own
        const scanned = new Set<Node>()
        for (const mutation of mutations) {
            // one record we cannot read must not end the batch: every record behind it would lose
            // its sign of life and the timeout backstop would report a false dead click
            try {
                // a root observed directly keeps reporting after its host leaves the page, and a change
                // off the page is no sign of life. only an explicit `false` is skipped, since older
                // browsers lack `isConnected`
                if (mutation.target?.isConnected === false) {
                    continue
                }
                this._lastMutation = Date.now()
                // added content can bring a shadow root of its own, which the observer that reported
                // the addition cannot see into
                const addedNodes = mutation.addedNodes
                for (let i = 0; i < addedNodes.length; i++) {
                    const node = addedNodes[i]
                    if (isInspectableElement(node) && !scanned.has(node)) {
                        this._observeShadowRoots(node, scanned)
                    }
                }
            } catch {}
        }
    }

    private _startClickObserver() {
        // Queue the click before application handlers can mutate the DOM and deliver mutation callbacks.
        addEventListener(assignableWindow, 'click', this._onClick, { capture: true })
        addEventListener(assignableWindow, 'mousedown', this._onMouseDown, { capture: true })
        addEventListener(assignableWindow, 'mouseup', this._onMouseUp, { capture: true })
        addEventListener(assignableWindow, 'mouseout', this._onMouseOut, { capture: true })
        addEventListener(assignableWindow, 'dragstart', this._clearMouseSelection, { capture: true })
        addEventListener(assignableWindow, 'pointercancel', this._clearMouseSelection, { capture: true })
        addEventListener(assignableWindow, 'blur', this._clearMouseSelection)
    }

    private _clearMouseSelection = (): void => {
        clearTimeout(this._mouseSelectionTimer)
        this._mouseSelectionTimer = undefined
        this._mouseSelection = undefined
    }

    private _onMouseDown = (event: Event): void => {
        this._observeGesturePath(event)
        this._clearMouseSelection()
        if ((event as MouseEvent).button === 0) {
            const gesture: MouseSelectionGesture = {
                path: event.composedPath(),
                trusted: event.isTrusted,
                selectionChanged: false,
                selectionInitiallyRelated: false,
            }
            const selection = document?.getSelection()
            gesture.selectionInitiallyRelated =
                selection?.type === 'Range' && this._selectionTouchesGesture(selection, gesture)
            this._mouseSelection = gesture
        }
    }

    private _onMouseOut = (event: Event): void => {
        // A release outside the document may never reach our mouseup listener.
        if (isNull((event as MouseEvent).relatedTarget)) {
            this._clearMouseSelection()
        }
    }

    private _onMouseUp = (event: Event): void => {
        const gesture = this._mouseSelection
        const mouseEvent = event as MouseEvent
        if (!gesture || mouseEvent.button !== 0 || event.isTrusted !== gesture.trusted) {
            return
        }
        const path = event.composedPath()
        // Native clicks target the nearest common ancestor of the press and release targets.
        // Composed paths preserve this relationship through accessible shadow boundaries.
        for (const node of gesture.path) {
            if (isInspectableElement(node) && path.indexOf(node) !== -1) {
                gesture.clickTarget = node
                break
            }
        }
        gesture.clickDetail = mouseEvent.detail
        // Mouseup and its native click are dispatched together. If no click follows, discard
        // the released gesture before a later activation can inherit its selection activity.
        this._mouseSelectionTimer = assignableWindow.setTimeout(this._clearMouseSelection, 0)
    }

    private _onClick = (event: Event): void => {
        // a click without a preceding mousedown, e.g. a keyboard activation, reaches us here first
        this._observeGesturePath(event)
        const mouseEvent = event as MouseEvent
        const click: ObservedDeadClick | null = asCandidate(mouseEvent, { type: 'click' })
        const gesture = this._mouseSelection
        if (
            click &&
            gesture &&
            mouseEvent.button === 0 &&
            mouseEvent.detail > 0 &&
            mouseEvent.detail === gesture.clickDetail &&
            event.isTrusted === gesture.trusted &&
            click.node === gesture.clickTarget
        ) {
            click.selectionChangedDuringGesture =
                gesture.selectionChanged && this._config.selection_change_threshold_ms > 0
            this._clearMouseSelection()
        }
        if (!isNull(click) && !this._ignore(click)) {
            this._queueCandidate(click)
        }
        this._scheduleCheck()
    }

    // Only store a pre-candidate selection delay when it is already inside the suppression window,
    // so it can never feed the post-click selection timeout. Keep the candidate queued until the
    // check so it can still deduplicate another click on the same node.
    private _queueCandidate(candidate: DeadClickCandidate): void {
        candidate.selectionChangedDelayMs = priorLivenessDelay(
            candidate.timestamp,
            this._lastSelectionChanged,
            this._config.selection_change_threshold_ms
        )
        candidate.visibilityChangedDelayMs = priorLivenessDelay(candidate.timestamp, this._lastVisibilityChange)
        candidate.focusChangedDelayMs = priorLivenessDelay(candidate.timestamp, this._lastFocusChange)
        this._clicks.push(candidate)
    }

    private _scheduleCheck() {
        if (this._clicks.length && isUndefined(this._checkClickTimer)) {
            this._checkClickTimer = assignableWindow.setTimeout(() => {
                this._checkClicks()
            }, 1000)
        }
    }

    // `capture: true` is required to get scroll events for other scrollable elements
    // on the page, not just the window
    // see https://developer.mozilla.org/en-US/docs/Web/API/EventTarget/addEventListener#usecapture
    //
    // `passive: true` is used to tell the browser that the scroll event handler will not call `preventDefault()`
    // This allows the browser to optimize scrolling performance by not waiting for our handling of the scroll event
    // see https://developer.mozilla.org/en-US/docs/Web/API/EventTarget/addEventListener#passive
    private _startScrollObserver() {
        addEventListener(assignableWindow, 'scroll', this._onScroll, { capture: true })
    }

    private _onScroll = (): void => {
        const candidateNow = Date.now()
        this._lastScroll = candidateNow
        // very naive throttle
        if (candidateNow % 50 === 0) {
            // we can see many scrolls between scheduled checks,
            // so we update scroll delay as we see them
            // to avoid false positives
            this._clicks.forEach((click) => {
                if (isUndefined(click.scrollDelayMs)) {
                    click.scrollDelayMs = candidateNow - click.timestamp
                }
            })
        }
    }

    private _startSelectionChangedObserver() {
        // A selection may already exist when the lazy-loaded detector starts.
        this._hadSelection = document?.getSelection()?.type === 'Range'
        // Document selections fire selectionchange directly on document and the event does not bubble.
        addEventListener(document, 'selectionchange', this._onSelectionChange)
    }

    private _selectionIsInGesture(node: Node | null | undefined, gesture: MouseSelectionGesture): boolean {
        const target = gesture.path[0] as Node
        try {
            while (node) {
                if (gesture.path.indexOf(node) !== -1 || (isElementNode(target) && target.contains(node))) {
                    return true
                }
                // Firefox can expose selection endpoints behind a closed root while mouse events
                // expose only its host. Compare both representations without traversing other content.
                node = (node.getRootNode() as ShadowRoot).host
            }
        } catch {
            // an endpoint we cannot read is an endpoint we cannot match to the gesture
        }
        return false
    }

    private _selectionTouchesGesture(selection: Selection, gesture: MouseSelectionGesture): boolean {
        const target = gesture.path[0] as Node
        const range = selection.rangeCount > 0 ? selection.getRangeAt(0) : undefined
        const sameRoot = !!range && trySafe(() => range.startContainer.getRootNode() === target.getRootNode())
        if (range && sameRoot && isElementNode(target)) {
            if (!range.collapsed) {
                return range.intersectsNode(target)
            }
            // A shadow selection can be represented as a collapsed boundary immediately before
            // its host. Resolve that boundary rather than associating its whole parent container.
            const node = isElementNode(range.startContainer)
                ? (range.startContainer.childNodes[range.startOffset] ?? range.startContainer)
                : range.startContainer
            return this._selectionIsInGesture(node, gesture)
        }
        return (
            this._selectionIsInGesture(selection.focusNode, gesture) ||
            this._selectionIsInGesture(selection.anchorNode, gesture)
        )
    }

    private _onSelectionChange = (event: Event): void => {
        const selection = document?.getSelection()
        const hadSelection = this._hadSelection
        // isCollapsed can be true for a range inside a shadow root; type reflects the actual selection.
        this._hadSelection = selection?.type === 'Range'

        const focusNode = selection?.focusNode
        const focusElement = focusNode && (isElementNode(focusNode) ? focusNode : focusNode.parentElement)
        // Selection endpoints may be retargeted outside an editor's shadow root.
        const documentActiveElement = document?.activeElement
        let activeElement = documentActiveElement
        while (activeElement?.shadowRoot?.activeElement) {
            activeElement = activeElement.shadowRoot.activeElement
        }
        const isEditing =
            isTextSelectionTarget(getEventTarget(event)) ||
            isTextSelectionTarget(focusElement ?? null) ||
            isTextSelectionTarget(activeElement ?? null)
        // A caret reported outside focused content may belong to a closed shadow root.
        // Preserve that activity when its actual target cannot be inspected.
        const hasRetargetedCaret =
            selection?.type === 'Caret' &&
            activeElement &&
            !activeElement.shadowRoot &&
            focusNode &&
            focusNode !== documentActiveElement &&
            focusNode.contains(documentActiveElement ?? null)

        // Ordinary clicks can move an invisible caret on known non-editable content.
        if (!hadSelection && !this._hadSelection && !isEditing && !hasRetargetedCaret) {
            return
        }

        const firedAt = Date.now()
        this._lastSelectionChanged = firedAt

        const gesture = this._mouseSelection
        // An opaque closed-root caret is only a possible editor. Keep its existing timed
        // fallback, but do not extend that uncertainty across a long press on inert content.
        if (gesture && (hadSelection || this._hadSelection || isEditing)) {
            const eventTarget = getEventTarget(event)
            let editor: Element | null | undefined
            if (isTextSelectionTarget(eventTarget)) {
                editor = eventTarget
            } else if (selection?.type === 'Caret') {
                if (isTextSelectionTarget(activeElement ?? null) || hasRetargetedCaret) {
                    editor = activeElement
                } else if (isEditing) {
                    editor = focusElement
                }
            }
            // Endpoint-less clearing must belong to the range present at press time; an
            // unrelated range removed elsewhere in the document must not suppress this click.
            const related = editor
                ? this._selectionIsInGesture(editor, gesture)
                : selection && (focusNode || selection.anchorNode)
                  ? this._selectionTouchesGesture(selection, gesture)
                  : hadSelection && !this._hadSelection && gesture.selectionInitiallyRelated
            gesture.selectionChanged = gesture.selectionChanged || related
        }

        // Keep the closest selection change after each candidate. A nearby change suppresses the
        // candidate; a later one retains the existing post-click timeout behavior.
        this._clicks.forEach((candidate) => {
            const delay = firedAt - candidate.timestamp
            if (
                delay >= 0 &&
                (isUndefined(candidate.selectionChangedDelayMs) || delay < candidate.selectionChangedDelayMs)
            ) {
                candidate.selectionChangedDelayMs = delay
            }
        })
    }

    private _startVisibilityChangeObserver() {
        addEventListener(document, 'visibilitychange', this._onVisibilityChange)
    }

    private _onVisibilityChange = (): void => {
        if (document?.visibilityState === 'hidden') {
            this._clearMouseSelection()
        }
        // record both directions: a tab going _hidden_ right after a click (the click opened a new
        // tab) is as much a liveness signal as it becoming visible (the click that woke the tab).
        // stamp queued candidates now, before a hidden tab can suspend `_checkClicks`.
        const firedAt = Date.now()
        this._lastVisibilityChange = firedAt
        this._recordLivenessSignal('visibilityChangedDelayMs', firedAt)
    }

    // a click that opens a new window/popup may leave the current tab visible, so its only trace is
    // the window losing focus. focus/blur are liveness signals too — they suppress a dead click, and
    // like visibility they never cause one.
    private _startFocusChangeObserver() {
        addEventListener(assignableWindow, 'blur', this._onFocusChange)
        addEventListener(assignableWindow, 'focus', this._onFocusChange)
    }

    private _onFocusChange = (): void => {
        const firedAt = Date.now()
        this._lastFocusChange = firedAt
        this._recordLivenessSignal('focusChangedDelayMs', firedAt)
    }

    // stamp each queued candidate with how long AFTER its click this liveness signal fired, the
    // moment the event arrives. recording it immediately — rather than reading a single shared
    // timestamp when `_checkClicks` finally runs — is what makes it robust: a hidden tab suspends
    // `_checkClicks`, and by the time it resumes a later transition (the tab coming back) would have
    // overwritten the click-correlated one. keeps the closest transition, only within the window.
    private _recordLivenessSignal(field: 'visibilityChangedDelayMs' | 'focusChangedDelayMs', firedAt: number): void {
        this._clicks.forEach((click) => {
            const delay = livenessDelayInWindow(firedAt - click.timestamp)
            if (isNumber(delay) && (isUndefined(click[field]) || delay < click[field]!)) {
                click[field] = delay
            }
        })
    }

    // `capture: true` mirrors the scroll observer so we see gestures on nested scrollable
    // elements too. `passive: true` tells the browser we won't call `preventDefault()`.
    private _startSwipeObserver() {
        addEventListener(assignableWindow, 'touchstart', this._onTouchStart, { capture: true, passive: true })
        addEventListener(assignableWindow, 'touchend', this._onTouchEnd, { capture: true, passive: true })
        // a cancelled gesture (system back-swipe, incoming call, etc.) never fires touchend,
        // so clear the start point to avoid measuring the next gesture from a stale origin
        addEventListener(assignableWindow, 'touchcancel', this._onTouchCancel, { capture: true, passive: true })
    }

    private _onTouchStart = (event: Event): void => {
        this._observeGesturePath(event)
        const touches = (event as TouchEvent).touches
        // only single-finger gestures are swipes; a second finger (pinch/zoom) is not,
        // so a multi-touch start clears any tracked origin rather than measuring against it
        const touch = touches?.length === 1 ? touches[0] : undefined
        this._touchStart = touch ? { x: touch.clientX, y: touch.clientY, timestamp: Date.now() } : undefined
    }

    private _onTouchCancel = (): void => {
        this._touchStart = undefined
    }

    private _onTouchEnd = (event: Event): void => {
        const start = this._touchStart
        this._touchStart = undefined
        if (isUndefined(start) || this._deadSwipesCaptured >= this._config.max_dead_swipes_per_page_load) {
            return
        }

        const touchEvent = event as TouchEvent
        const touch = touchEvent.changedTouches?.[0]
        if (!touch) {
            return
        }

        const dx = touch.clientX - start.x
        const dy = touch.clientY - start.y
        const distanceSq = dx * dx + dy * dy
        // compare squared distances to avoid a sqrt on every touch; only the actual swipes need it
        const threshold = this._config.swipe_threshold_px
        if (distanceSq < threshold * threshold) {
            // a short movement is a tap or a jitter, not a swipe
            return
        }

        // a gesture that already did something while the finger was down — dragging scrolled
        // the page, a finger-following carousel mutated the DOM, a text selection grew — is not
        // dead, so it never becomes a candidate. surviving candidates keep the touchend
        // timestamp: the thresholds in _checkClicks measure how quickly the page responds
        // after the finger lifts, just as they measure the response to a click
        const gestureCausedActivity = [this._lastScroll, this._lastMutation, this._lastSelectionChanged].some(
            (lastActivityAt) => isNumber(lastActivityAt) && lastActivityAt >= start.timestamp
        )
        if (gestureCausedActivity) {
            return
        }

        // hit-test the stack under where the finger landed rather than the candidate's
        // ancestors: canvas apps usually receive their touches through transparent overlay
        // elements stacked on top of the canvas, so the surface is beneath, not above.
        // this runs at most once per dead-candidate gesture, when the page is provably idle
        // (the activity gate above just passed), so a forced layout flush is unlikely
        if (this._pageHasUnobservableSurfaces()) {
            const stack = document?.elementsFromPoint?.(start.x, start.y) ?? []
            if (stack.some((el) => el.matches?.(UNOBSERVABLE_SURFACE_SELECTOR))) {
                return
            }
        }

        const swipe = asCandidate(touchEvent, {
            type: 'swipe',
            swipeDirection: swipeDirection(dx, dy),
            swipeDistancePx: Math.round(Math.sqrt(distanceSq)),
        })
        if (!isNull(swipe) && !this._ignore(swipe)) {
            this._queueCandidate(swipe)
        }
        this._scheduleCheck()
    }

    // whether the page contains surfaces whose response to a gesture we cannot observe —
    // cached, recomputed lazily and only when the DOM has mutated since the last look
    private _pageHasUnobservableSurfaces(): boolean {
        const domChangedSinceCheck =
            isUndefined(this._surfacesCheckedAt) ||
            (isNumber(this._lastMutation) && this._lastMutation > this._surfacesCheckedAt)
        if (isUndefined(this._hasUnobservableSurfaces) || domChangedSinceCheck) {
            this._surfacesCheckedAt = Date.now()
            this._hasUnobservableSurfaces = !!document?.querySelector(UNOBSERVABLE_SURFACE_SELECTOR)
        }
        return !!this._hasUnobservableSurfaces
    }

    private _ignore(candidate: DeadClickCandidate | null): boolean {
        if (!candidate) {
            return true
        }
        // swipes run only the shared gates; clicks layer their own intent gates on top
        return candidate.type === 'swipe' ? this._ignoreCommon(candidate) : this._ignoreClick(candidate)
    }

    // gates that apply to every dead candidate, whatever the gesture
    private _ignoreCommon(candidate: DeadClickCandidate): boolean {
        if (isElementInToolbar(candidate.node)) {
            return true
        }

        const alreadySeenInLastSecond = this._clicks.some((c) => {
            return (
                c.type === candidate.type &&
                c.node === candidate.node &&
                Math.abs(c.timestamp - candidate.timestamp) < 1000
            )
        })
        if (alreadySeenInLastSecond) {
            return true
        }

        if (isTag(candidate.node, 'html') || !isElementNode(candidate.node)) {
            return true
        }

        return !shouldCaptureDeadClick(candidate.node, {
            css_selector_ignorelist: this._config.css_selector_ignorelist,
        })
    }

    // click-only gates, layered on top of the shared ones
    private _ignoreClick(candidate: DeadClickCandidate): boolean {
        // clicks with modifier keys (open in new tab, etc.) are intentional; touch swipes have no modifiers
        if (!this._config.capture_clicks_with_modifier_keys && hasModifierKey(candidate.originalEvent)) {
            return true
        }

        if (this._ignoreCommon(candidate)) {
            return true
        }

        // an anchor is a legitimate click activation so we skip it, but a swipe that fails to
        // navigate is the signal we want — which is why anchors are skipped for clicks only.
        // reaching here means _ignoreCommon confirmed an element node, so this is safe to call
        return shouldSkipDeadClick(candidate.node)
    }

    private _checkClicks() {
        if (!this._clicks.length) {
            return
        }

        clearTimeout(this._checkClickTimer)
        this._checkClickTimer = undefined

        const clicksToCheck = this._clicks
        this._clicks = []

        for (const click of clicksToCheck) {
            click.mutationDelayMs =
                click.mutationDelayMs ??
                (this._lastMutation && click.timestamp <= this._lastMutation
                    ? this._lastMutation - click.timestamp
                    : undefined)
            click.absoluteDelayMs = Date.now() - click.timestamp
            // Selection/visibility/focus delays are recorded on each candidate as their events fire.
            // The pre-candidate directions are handled in `_queueCandidate`. Nothing uses a shared
            // timestamp here, so a later event cannot overwrite the change related to this candidate.

            const scrollTimeout = checkTimeout(click.scrollDelayMs, this._config.scroll_threshold_ms)
            const selectionChangedTimeout = checkTimeout(
                click.selectionChangedDelayMs,
                this._config.selection_change_threshold_ms
            )
            const mutationTimeout = checkTimeout(click.mutationDelayMs, this._config.mutation_threshold_ms)
            // we want to timeout eventually even if nothing else catches it...
            // we leave a little longer than the maximum threshold to give the other checks a chance to catch it
            const absoluteTimeout = checkTimeout(click.absoluteDelayMs, this._config.mutation_threshold_ms * 1.1)

            const hadScroll = isNumber(click.scrollDelayMs) && click.scrollDelayMs < this._config.scroll_threshold_ms
            const hadMutation =
                isNumber(click.mutationDelayMs) && click.mutationDelayMs < this._config.mutation_threshold_ms
            const hadSelectionChange =
                click.selectionChangedDuringGesture ||
                (isNumber(click.selectionChangedDelayMs) &&
                    click.selectionChangedDelayMs < this._config.selection_change_threshold_ms)
            // visibility/focus delays are only ever recorded when already inside the suppression
            // window (see `livenessDelayInWindow`), so their presence alone means "suppress"
            const hadVisibilityChange = isNumber(click.visibilityChangedDelayMs)
            const hadFocusChange = isNumber(click.focusChangedDelayMs)

            if (hadScroll || hadMutation || hadSelectionChange || hadVisibilityChange || hadFocusChange) {
                continue
            }

            if (scrollTimeout || mutationTimeout || absoluteTimeout || selectionChangedTimeout) {
                const prefix = deadEventName(click)
                if (prefix === '$dead_swipe') {
                    if (this._deadSwipesCaptured >= this._config.max_dead_swipes_per_page_load) {
                        // the page-load budget for dead swipes is spent — drop, don't requeue
                        continue
                    }
                    this._deadSwipesCaptured++
                }
                this._onCapture(click, {
                    [`${prefix}_last_mutation_timestamp`]: this._lastMutation,
                    [`${prefix}_event_timestamp`]: click.timestamp,
                    [`${prefix}_scroll_timeout`]: scrollTimeout,
                    [`${prefix}_mutation_timeout`]: mutationTimeout,
                    [`${prefix}_absolute_timeout`]: absoluteTimeout,
                    [`${prefix}_selection_changed_timeout`]: selectionChangedTimeout,
                    // visibility changes only ever suppress a dead click, never cause one; kept in the
                    // payload (always false) so the event shape is unchanged for existing consumers
                    [`${prefix}_visibility_changed_timeout`]: false,
                })
            } else if (click.absoluteDelayMs < this._config.mutation_threshold_ms) {
                // keep waiting until next check
                this._clicks.push(click)
            }
        }

        this._scheduleCheck()
    }

    private _captureDeadClick(click: DeadClickCandidate, properties: Properties) {
        // TODO need to check safe and captur-able as with autocapture
        // TODO autocaputure config
        const prefix = deadEventName(click)
        this.instance.capture(
            prefix,
            {
                ...properties,
                ...autocapturePropertiesForElement(click.node, {
                    e: click.originalEvent,
                    maskAllElementAttributes: this.instance.config.mask_all_element_attributes,
                    maskAllText: this.instance.config.mask_all_text,
                    elementAttributeIgnoreList: this._config.element_attribute_ignorelist,
                    // TRICKY: it appears that we were moving to elementsChainAsString, but the UI still depends on elements, so :shrug:
                    elementsChainAsString: false,
                    disableCaptureUrlHashes: this.instance.config.disable_capture_url_hashes,
                }).props,
                [`${prefix}_scroll_delay_ms`]: click.scrollDelayMs,
                [`${prefix}_mutation_delay_ms`]: click.mutationDelayMs,
                [`${prefix}_absolute_delay_ms`]: click.absoluteDelayMs,
                [`${prefix}_selection_changed_delay_ms`]: click.selectionChangedDelayMs,
                [`${prefix}_visibility_changed_delay_ms`]: click.visibilityChangedDelayMs,
                [`${prefix}_focus_changed_delay_ms`]: click.focusChangedDelayMs,
                // undefined for clicks (stripped on serialization), like the delay fields above
                $dead_swipe_direction: click.swipeDirection,
                $dead_swipe_distance_px: click.swipeDistancePx,
            },
            {
                timestamp: new Date(click.timestamp),
            }
        )
    }
}

assignableWindow.__PosthogExtensions__ = assignableWindow.__PosthogExtensions__ || {}
assignableWindow.__PosthogExtensions__.initDeadClicksAutocapture = (ph, config) =>
    new LazyLoadedDeadClicksAutocapture(ph, config)

export default LazyLoadedDeadClicksAutocapture
