// Portions of this file are derived from getsentry/sentry-javascript
// Copyright (c) 2012 Functional Software, Inc. dba Sentry
// Licensed under the MIT License: https://github.com/getsentry/sentry-javascript/blob/develop/LICENSE

/// <reference lib="dom" />

// rrweb/network@1 code starts
// most of what is below here will be removed when rrweb release their code for this
// see https://github.com/rrweb-io/rrweb/pull/1105

// NB adopted from https://github.com/rrweb-io/rrweb/pull/1105 which looks like it will be accepted into rrweb
// however, in the PR, it throws when the performance observer data is not available
// and assumes it is running in a browser with the Request API (i.e. not IE11)
// copying here so that we can use it before rrweb adopt it

import type { IWindow, listenerHandler, RecordPlugin } from '../types/rrweb-types'
import { CapturedNetworkRequest, Headers, InitiatorType, NetworkRecordOptions } from '../../../types'
import {
    isArray,
    isBoolean,
    isFormData,
    isFunction,
    isNull,
    isNullish,
    isString,
    isUndefined,
    isObject,
} from '@posthog/core'
import { isDocument } from '@posthog/browser-common/utils/type-utils'
import { createLogger } from '@posthog/browser-common/utils/logger'
import { formDataToQuery } from '@posthog/browser-common/utils/request-utils'
import { patch } from '../rrweb-plugins/patch'
import { isHostOnDenyList } from '../../../extensions/replay/external/denylist'
import { defaultNetworkOptions, effectivePayloadLimitBytes, isInitialMaskFallback } from './config'

const logger = createLogger('[Recorder]')

export type NetworkData = {
    requests: CapturedNetworkRequest[]
    isInitial?: boolean
}

// Internal recorder option, not a user-facing network capture setting. Missing means legacy ordering.
type NetworkPluginOptions = NetworkRecordOptions & { captureFetchSynchronously?: boolean }

type networkCallback = (data: NetworkData) => void

const isNavigationTiming = (entry: PerformanceEntry): entry is PerformanceNavigationTiming =>
    entry.entryType === 'navigation'
const isResourceTiming = (entry: PerformanceEntry): entry is PerformanceResourceTiming => entry.entryType === 'resource'

type ObservedPerformanceEntry = (PerformanceNavigationTiming | PerformanceResourceTiming) & {
    responseStatus?: number
}

export function findLast<T>(array: Array<T>, predicate: (value: T) => boolean): T | undefined {
    const length = array.length
    for (let i = length - 1; i >= 0; i -= 1) {
        if (predicate(array[i])) {
            return array[i]
        }
    }
    return undefined
}

const noopHandler: listenerHandler = () => {
    //
}

// a partial navigation entry is readable before load and the observer delivers it again once complete.
// readiness turns `complete` before the load event fires, so only a non-zero `loadEventEnd` is final
function isCompletedNavigationTiming(win: IWindow, entry: PerformanceEntry): entry is PerformanceNavigationTiming {
    return isNavigationTiming(entry) && win.document?.readyState === 'complete' && entry.loadEventEnd > 0
}

// an `entryTypes` observation never delivers an entry that completed before it started
function completedNavigationEntries(win: IWindow): PerformanceNavigationTiming[] {
    if (win.document?.readyState !== 'complete') {
        return []
    }
    return win.performance
        .getEntriesByType('navigation')
        .filter((entry): entry is PerformanceNavigationTiming => isCompletedNavigationTiming(win, entry))
}

// if we are only observing timings then we could have a single observer for all types, with buffer true,
// but we are going to filter by initiatorType _if we are wrapping fetch and xhr as the wrapped functions
// will deal with those.
// so we have a block which captures requests from before fetch/xhr is wrapped
// these are marked `isInitial` so playback can display them differently if needed
// they will never have method/status/headers/body because they are pre-wrapping that provides that
// resource entries stay behind `recordInitialRequests`, the navigation entry is the document load
// timing the waterfall is built from, so it is read whenever navigation is observed at all
function initialEntries(win: IWindow, options: Required<NetworkRecordOptions>): ObservedPerformanceEntry[] {
    if (options.recordInitialRequests) {
        return win.performance
            .getEntries()
            .filter(
                (entry): entry is ObservedPerformanceEntry =>
                    isCompletedNavigationTiming(win, entry) ||
                    (isResourceTiming(entry) && options.initiatorTypes.includes(entry.initiatorType as InitiatorType))
            )
    }
    return options.performanceEntryTypeToObserve.includes('navigation') ? completedNavigationEntries(win) : []
}

// undefined means this frame cannot observe performance entries, so the caller can tell
// "nothing to tear down" apart from "nothing started here"
function initPerformanceObserver(
    cb: networkCallback,
    win: IWindow,
    options: Required<NetworkRecordOptions>
): listenerHandler | undefined {
    // Masking errors are isolated per record. Guard initial entry collection/preparation too:
    // rrweb tears down all registered observers if plugin initialization throws.
    try {
        cb({
            requests: initialEntries(win, options).flatMap((entry) =>
                prepareRequest(win, {
                    entry,
                    method: undefined,
                    status: undefined,
                    networkRequest: {},
                    isInitial: true,
                })
            ),
            isInitial: true,
        })
    } catch (e) {
        logger.error('Failed to capture initial performance entries for network capture', e)
    }
    // some frames have no PerformanceObserver, or one without the static list of entry types,
    // so live network capture is not available there
    const performanceObserverClass = win.PerformanceObserver as typeof PerformanceObserver | undefined
    const supportedEntryTypes = performanceObserverClass?.supportedEntryTypes
    if (!performanceObserverClass || !isArray(supportedEntryTypes)) {
        return undefined
    }
    const entryTypes = supportedEntryTypes.filter((x) => options.performanceEntryTypeToObserve.includes(x))
    if (!entryTypes.length) {
        // observe() throws when it is given no valid entry type
        return undefined
    }

    const observer = new performanceObserverClass((entries) => {
        // if recordBody or recordHeaders is true then we don't want to record fetch or xhr here
        // as the wrapped functions will do that. Otherwise, this filter becomes a noop
        // because we do want to record them here
        const wrappedInitiatorFilter = (entry: ObservedPerformanceEntry) =>
            options.recordBody || options.recordHeaders
                ? entry.initiatorType !== 'xmlhttprequest' && entry.initiatorType !== 'fetch'
                : true

        const performanceEntries = entries.getEntries().filter(
            (entry): entry is ObservedPerformanceEntry =>
                isNavigationTiming(entry) ||
                (isResourceTiming(entry) &&
                    options.initiatorTypes.includes(entry.initiatorType as InitiatorType) &&
                    // TODO if we are _only_ capturing timing we don't want to filter initiator here
                    wrappedInitiatorFilter(entry))
        )

        cb({
            requests: performanceEntries.flatMap((entry) =>
                prepareRequest(win, { entry, method: undefined, status: undefined, networkRequest: {} })
            ),
        })
    })
    // initial records are gathered above, so we don't need to observe and buffer each type separately
    observer.observe({ entryTypes })
    return () => {
        observer.disconnect()
    }
}

function shouldRecordHeaders(type: 'request' | 'response', recordHeaders: NetworkRecordOptions['recordHeaders']) {
    return !!recordHeaders && (isBoolean(recordHeaders) || recordHeaders[type])
}

function isRequest(value: unknown): value is Request {
    if (typeof Request === 'undefined') {
        return false
    }
    if (value instanceof Request) {
        return true
    }
    try {
        return Object.prototype.toString.call(value) === '[object Request]'
    } catch {
        return false
    }
}

// binary/asset bodies are large and useless for replay debugging (and capturing an image body
// duplicates what the recording already shows), so we never record them even when recordBody is on
export const NEVER_RECORD_BODY_CONTENT_TYPES = [
    'image/',
    'video/',
    'audio/',
    'font/',
    'application/octet-stream',
    'application/pdf',
    'application/zip',
    'application/wasm',
]

export function shouldRecordBody({
    type,
    recordBody,
    headers,
    url,
}: {
    type: 'request' | 'response'
    headers: Headers
    url: string | URL | RequestInfo
    recordBody: NetworkRecordOptions['recordBody']
}) {
    function matchesContentType(contentTypes: string[]) {
        const contentTypeHeader = Object.keys(headers).find((key) => key.toLowerCase() === 'content-type')
        const contentType = contentTypeHeader && headers[contentTypeHeader]
        return contentTypes.some((ct) => contentType?.toLowerCase().includes(ct))
    }

    /**
     * particularly in canvas applications we see many requests to blob URLs
     * e.g. blob:https://video_url
     * these blob/object URLs are local to the browser, we can never capture that body
     * so we can just return false here
     */
    function isBlobURL(url: string | URL | RequestInfo) {
        try {
            if (typeof url === 'string') {
                return url.startsWith('blob:')
            }
            if (url instanceof URL) {
                return url.protocol === 'blob:'
            }
            if (isRequest(url)) {
                return isBlobURL(url.url)
            }
            return false
        } catch {
            return false
        }
    }
    if (!recordBody) return false
    if (isBlobURL(url)) return false
    // never record binary/asset bodies, regardless of the recordBody setting
    if (matchesContentType(NEVER_RECORD_BODY_CONTENT_TYPES)) return false
    if (isBoolean(recordBody)) return true
    if (isArray(recordBody)) return matchesContentType(recordBody)
    const recordBodyType = recordBody[type]
    if (isBoolean(recordBodyType)) return recordBodyType
    return matchesContentType(recordBodyType)
}

async function getRequestPerformanceEntry(
    win: IWindow,
    initiatorType: string,
    url: string,
    start?: number,
    end?: number,
    attempt = 0
): Promise<PerformanceResourceTiming | null> {
    if (attempt > 10) {
        logger.warn('Failed to get performance entry for request', { url, initiatorType })
        return null
    }
    const urlPerformanceEntries = win.performance.getEntriesByName(url) as PerformanceResourceTiming[]
    const performanceEntry = findLast(
        urlPerformanceEntries,
        (entry) =>
            isResourceTiming(entry) &&
            entry.initiatorType === initiatorType &&
            (isUndefined(start) || entry.startTime >= start) &&
            (isUndefined(end) || entry.startTime <= end)
    )
    if (!performanceEntry) {
        await new Promise((resolve) => setTimeout(resolve, 50 * attempt))
        return getRequestPerformanceEntry(win, initiatorType, url, start, end, attempt + 1)
    }
    return performanceEntry
}

/**
 * According to MDN https://developer.mozilla.org/en-US/docs/Web/API/XMLHttpRequest/response
 * xhr response is typed as any but can be an ArrayBuffer, a Blob, a Document, a JavaScript object,
 * or a string, depending on the value of XMLHttpRequest.responseType, that contains the response entity body.
 *
 * XHR request body is Document | XMLHttpRequestBodyInit | null | undefined
 */
function _tryReadXHRBody({
    body,
    options,
    url,
}: {
    body: Document | XMLHttpRequestBodyInit | any | null | undefined
    options: NetworkRecordOptions
    url: string | URL | RequestInfo
}): string | null {
    if (isNullish(body)) {
        return null
    }

    const { hostname, isHostDenied } = isHostOnDenyList(url, options)
    if (isHostDenied) {
        return hostname + ' is in deny list'
    }

    if (isString(body)) {
        return body
    }

    if (isDocument(body)) {
        return body.textContent
    }

    if (isFormData(body)) {
        return formDataToQuery(body)
    }

    if (isObject(body)) {
        try {
            return JSON.stringify(body)
        } catch {
            return '[SessionReplay] Failed to stringify response object'
        }
    }

    return '[SessionReplay] Cannot read body of type ' + toString.call(body)
}

function initXhrObserver(cb: networkCallback, win: IWindow, options: Required<NetworkRecordOptions>): listenerHandler {
    if (!options.initiatorTypes.includes('xmlhttprequest')) {
        return () => {
            //
        }
    }
    const recordRequestHeaders = shouldRecordHeaders('request', options.recordHeaders)
    const recordResponseHeaders = shouldRecordHeaders('response', options.recordHeaders)

    const restorePatch = patch(
        win.XMLHttpRequest.prototype,
        'open',
        // oxlint-disable-next-line typescript/ban-ts-comment
        // @ts-ignore
        (originalOpen: typeof XMLHttpRequest.prototype.open) => {
            return function (
                method: string,
                url: string | URL,
                async = true,
                username?: string | null,
                password?: string | null
            ) {
                // because this function is returned in its actual context `this` _is_ an XMLHttpRequest
                // oxlint-disable-next-line typescript/ban-ts-comment
                // @ts-ignore
                const xhr = this as XMLHttpRequest

                // All of the capture instrumentation below runs _before_ we delegate to the original
                // `open`. If any of it throws (e.g. `new Request(url)` rejecting a URL/method the host
                // application would have handled), we must not let that exception escape into the host's
                // `xhr.open()` call and misattribute a failure to session replay. Wrap it so that if
                // instrumentation fails we degrade gracefully and the original request still proceeds.
                try {
                    // check IE earlier than this, we only initialize if Request is present
                    const req = new Request(url)
                    const networkRequest: Partial<CapturedNetworkRequest> = {}
                    let start: number | undefined
                    let end: number | undefined

                    const requestHeaders: Headers = {}
                    const originalSetRequestHeader = xhr.setRequestHeader.bind(xhr)
                    xhr.setRequestHeader = (header: string, value: string) => {
                        requestHeaders[header] = value
                        return originalSetRequestHeader(header, value)
                    }
                    if (recordRequestHeaders) {
                        networkRequest.requestHeaders = requestHeaders
                    }

                    const originalSend = xhr.send.bind(xhr)
                    xhr.send = (body) => {
                        if (
                            shouldRecordBody({
                                type: 'request',
                                headers: requestHeaders,
                                url,
                                recordBody: options.recordBody,
                            })
                        ) {
                            networkRequest.requestBody = _tryReadXHRBody({ body, options, url })
                        }
                        start = win.performance.now()
                        return originalSend(body)
                    }

                    // Cleanup function to remove all event listeners and prevent memory leaks
                    const cleanup = () => {
                        xhr.removeEventListener('readystatechange', readyStateListener)
                        xhr.removeEventListener('error', cleanup)
                        xhr.removeEventListener('abort', cleanup)
                        xhr.removeEventListener('timeout', cleanup)
                    }

                    const readyStateListener = () => {
                        if (xhr.readyState !== xhr.DONE) {
                            return
                        }

                        // Clean up all listeners immediately when done to prevent memory leaks
                        cleanup()

                        end = win.performance.now()
                        const responseHeaders: Headers = {}
                        const rawHeaders = xhr.getAllResponseHeaders()
                        const headers = rawHeaders.trim().split(/[\r\n]+/)
                        headers.forEach((line) => {
                            const parts = line.split(': ')
                            const header = parts.shift()
                            const value = parts.join(': ')
                            if (header) {
                                responseHeaders[header] = value
                            }
                        })
                        if (recordResponseHeaders) {
                            networkRequest.responseHeaders = responseHeaders
                        }
                        if (
                            shouldRecordBody({
                                type: 'response',
                                headers: responseHeaders,
                                url,
                                recordBody: options.recordBody,
                            })
                        ) {
                            networkRequest.responseBody = _tryReadXHRBody({ body: xhr.response, options, url })
                        }
                        getRequestPerformanceEntry(win, 'xmlhttprequest', req.url, start, end)
                            .then((entry) => {
                                const requests = prepareRequest(win, {
                                    entry,
                                    method: method,
                                    status: xhr?.status,
                                    networkRequest,
                                    start,
                                    end,
                                    url: url.toString(),
                                    initiatorType: 'xmlhttprequest',
                                })
                                cb({ requests })
                            })
                            .catch(() => {
                                //
                            })
                    }

                    // This is very tricky code, and making it passive won't bring many performance benefits,
                    // so let's ignore the rule here.
                    // oxlint-disable-next-line posthog-js/no-add-event-listener
                    xhr.addEventListener('readystatechange', readyStateListener)
                    // Also clean up on error, abort, and timeout to prevent memory leaks
                    // oxlint-disable-next-line posthog-js/no-add-event-listener
                    xhr.addEventListener('error', cleanup)
                    // oxlint-disable-next-line posthog-js/no-add-event-listener
                    xhr.addEventListener('abort', cleanup)
                    // oxlint-disable-next-line posthog-js/no-add-event-listener
                    xhr.addEventListener('timeout', cleanup)
                } catch (e) {
                    logger.error('Failed to instrument XHR for network capture', e)
                }

                originalOpen.call(xhr, method, url.toString(), async, username, password)
            }
        }
    )
    return () => {
        restorePatch()
    }
}

/**
 *  Check if this PerformanceEntry is either a PerformanceResourceTiming or a PerformanceNavigationTiming
 *  NB PerformanceNavigationTiming extends PerformanceResourceTiming
 *  Here we don't care which interface it implements as both expose `serverTimings`
 */
const exposesServerTiming = (event: PerformanceEntry | null): event is PerformanceResourceTiming =>
    !isNull(event) && (event.entryType === 'navigation' || event.entryType === 'resource')

// entry times count from the recorded frame's time origin, so the epoch base must come from that frame's clock
function prepareRequest(
    win: IWindow,
    {
        entry,
        method,
        status,
        networkRequest,
        isInitial,
        start,
        end,
        url,
        initiatorType,
    }: {
        entry: PerformanceResourceTiming | null
        method: string | undefined
        status: number | undefined
        networkRequest: Partial<CapturedNetworkRequest>
        isInitial?: boolean
        start?: number
        end?: number
        // if there is no performance observer entry, we still need to know the url
        url?: string
        // if there is no performance observer entry, we can provide the initiatorType
        initiatorType?: string
    }
): CapturedNetworkRequest[] {
    start = entry ? entry.startTime : start
    end = entry ? entry.responseEnd : end

    // kudos to sentry javascript sdk for excellent background on why to use Date.now() here
    // https://github.com/getsentry/sentry-javascript/blob/e856e40b6e71a73252e788cd42b5260f81c9c88e/packages/utils/src/time.ts#L70
    // can't start observer if performance.now() is not available
    const timeOrigin = Math.floor(Date.now() - win.performance.now())
    // clickhouse can't ingest timestamps that are floats
    // (in this case representing fractions of a millisecond we don't care about anyway)
    // use timeOrigin if we really can't gather a start time
    const timestamp = Math.floor(timeOrigin + (start || 0))

    // toJSON() keeps browser objects such as PerformanceServerTiming,
    // and postMessage from a cross-origin iframe cannot clone them
    const entryJSON = entry ? JSON.parse(JSON.stringify(entry.toJSON())) : { name: url }

    const requests: CapturedNetworkRequest[] = [
        {
            ...entryJSON,
            startTime: isUndefined(start) ? undefined : Math.round(start),
            endTime: isUndefined(end) ? undefined : Math.round(end),
            timeOrigin,
            timestamp,
            method: method,
            initiatorType: initiatorType ? initiatorType : entry ? (entry.initiatorType as InitiatorType) : undefined,
            status,
            requestHeaders: networkRequest.requestHeaders,
            requestBody: networkRequest.requestBody,
            responseHeaders: networkRequest.responseHeaders,
            responseBody: networkRequest.responseBody,
            isInitial,
        },
    ]

    if (exposesServerTiming(entry)) {
        for (const timing of entry.serverTiming || []) {
            requests.push({
                timeOrigin,
                timestamp,
                startTime: Math.round(entry.startTime),
                name: timing.name,
                duration: timing.duration,
                // the spec has a closed list of possible types
                // https://developer.mozilla.org/en-US/docs/Web/API/PerformanceEntry/entryType
                // but, we need to know this was a server timing so that we know to
                // match it to the appropriate navigation or resource timing
                // that matching will have to be on timestamp and $current_url
                entryType: 'serverTiming',
            })
        }
    }

    return requests
}

const contentTypePrefixDenyList = ['video/', 'audio/']

function _checkForCannotReadResponseBody({
    r,
    options,
    url,
}: {
    r: Response
    options: NetworkRecordOptions
    url: string | URL | RequestInfo
}): string | null {
    if (r.headers.get('Transfer-Encoding') === 'chunked') {
        return 'Chunked Transfer-Encoding is not supported'
    }

    // `get` and `has` are case-insensitive
    // but return the header value with the casing that was supplied
    const contentType = r.headers.get('Content-Type')?.toLowerCase()
    const contentTypeIsDenied = contentTypePrefixDenyList.some((prefix) => contentType?.startsWith(prefix))
    if (contentType && contentTypeIsDenied) {
        return `Content-Type ${contentType} is not supported`
    }

    const { hostname, isHostDenied } = isHostOnDenyList(url, options)
    if (isHostDenied) {
        return hostname + ' is in deny list'
    }

    return null
}

function isReadableStreamBody(body: unknown): body is ReadableStream<Uint8Array> {
    return isObject(body) && isFunction(body.getReader) && isFunction(body.tee)
}

// reading a body must never hold up the page's request for long, so we cap every read attempt
const BODY_READ_TIMEOUT_MS = 500
const BODY_READ_TIMEOUT_MESSAGE = '[SessionReplay] Timeout while trying to read body'
const BODY_READ_FAILED_MESSAGE = '[SessionReplay] Failed to read body'

function bodyReadFailedMessage(reason: unknown): string {
    return `${BODY_READ_FAILED_MESSAGE}: ${reason}`
}

function bodyTooLargeMessage(limitBytes: number): string {
    return `[SessionReplay] Body too large to record (> ${limitBytes} bytes)`
}

// when the body declares a content-length over the limit we can skip reading it entirely.
// this trusts content-length the same way config.ts enforcePayloadSizeLimit does.
// known accepted risk: for a compressed response content-length is the compressed size while the
// streaming reader counts decoded bytes, so a body that is over the limit compressed but under it
// decoded is dropped to the placeholder rather than recorded. it never breaks the page, so we accept it.
export function _contentLengthExceedsLimit(r: Request | Response, limitBytes: number): boolean {
    try {
        const headerValue = r.headers?.get?.('content-length')
        if (!headerValue) {
            return false
        }
        const contentLength = parseInt(headerValue, 10)
        return Number.isFinite(contentLength) && contentLength > limitBytes
    } catch {
        return false
    }
}

export function _readBody(r: Request | Response, options: NetworkRecordOptions): Promise<string> {
    if (!options.streamNetworkBody) {
        return _tryReadBody(r)
    }
    const limitBytes = effectivePayloadLimitBytes(options)
    // skip the read for bodies the headers already tell us are over the limit
    if (_contentLengthExceedsLimit(r, limitBytes)) {
        return Promise.resolve(bodyTooLargeMessage(limitBytes))
    }
    return _tryReadBodyStreaming(r, limitBytes)
}

function _tryReadBody(r: Request | Response): Promise<string> {
    // there are now already multiple places where we're using Promise...
    // oxlint-disable-next-line compat/compat
    return new Promise((resolve) => {
        const timeout = setTimeout(() => resolve(BODY_READ_TIMEOUT_MESSAGE), BODY_READ_TIMEOUT_MS)
        try {
            r.clone()
                .text()
                .then(
                    (txt) => resolve(txt),
                    (reason) => resolve(bodyReadFailedMessage(reason))
                )
                .finally(() => clearTimeout(timeout))
        } catch {
            clearTimeout(timeout)
            resolve(BODY_READ_FAILED_MESSAGE)
        }
    })
}

function concatChunks(chunks: Uint8Array[], totalBytes: number): Uint8Array {
    const merged = new Uint8Array(totalBytes)
    let offset = 0
    for (const chunk of chunks) {
        merged.set(chunk, offset)
        offset += chunk.byteLength
    }
    return merged
}

// Reads a clone of the body chunk by chunk, stopping as soon as the running total exceeds the
// limit, so a very large body is never fully buffered. Like _tryReadBody it only ever reads a
// clone (never the stream the page consumes) and is guaranteed to resolve, never reject.
export function _tryReadBodyStreaming(r: Request | Response, limitBytes: number): Promise<string> {
    // oxlint-disable-next-line compat/compat
    return new Promise((resolve) => {
        let settled = false
        let reader: ReadableStreamDefaultReader<Uint8Array> | undefined

        function cancel(): void {
            try {
                void reader?.cancel().catch(() => {})
            } catch {
                // the reader may already be released; nothing to clean up
            }
        }

        // resolving always releases the reader, so a slow/hung stream stops being pulled (and stops
        // buffering the clone) the moment we settle — whether via success, the cap, an error, or the timeout
        function done(value: string): void {
            if (settled) {
                return
            }
            settled = true
            clearTimeout(timeout)
            cancel()
            resolve(value)
        }

        const timeout = setTimeout(() => done(BODY_READ_TIMEOUT_MESSAGE), BODY_READ_TIMEOUT_MS)

        let clone: Request | Response
        try {
            clone = r.clone()
        } catch {
            done(BODY_READ_FAILED_MESSAGE)
            return
        }

        const body = clone.body
        // no readable stream (or no TextDecoder) available — fall back to the buffered read of the clone
        if (!isReadableStreamBody(body) || typeof TextDecoder === 'undefined') {
            try {
                clone.text().then(
                    (txt) => done(txt),
                    (reason) => done(bodyReadFailedMessage(reason))
                )
            } catch {
                done(BODY_READ_FAILED_MESSAGE)
            }
            return
        }

        try {
            reader = body.getReader()
        } catch {
            done(BODY_READ_FAILED_MESSAGE)
            return
        }

        const chunks: Uint8Array[] = []
        let received = 0

        function pump(): void {
            reader!.read().then(
                ({ done: streamDone, value }) => {
                    // already resolved (e.g. the timeout fired) — stop reading and release the stream
                    if (settled) {
                        cancel()
                        return
                    }

                    if (streamDone) {
                        done(new TextDecoder().decode(concatChunks(chunks, received)))
                        return
                    }

                    if (value) {
                        if (received + value.byteLength > limitBytes) {
                            done(bodyTooLargeMessage(limitBytes))
                            return
                        }
                        received += value.byteLength
                        chunks.push(value)
                    }

                    pump()
                },
                (reason) => done(bodyReadFailedMessage(reason))
            )
        }

        pump()
    })
}

async function _tryReadRequestBody({
    r,
    options,
    url,
}: {
    r: Request
    options: NetworkRecordOptions
    url: string | URL | RequestInfo
}): Promise<string> {
    const { hostname, isHostDenied } = isHostOnDenyList(url, options)
    if (isHostDenied) {
        return Promise.resolve(hostname + ' is in deny list')
    }

    return _readBody(r, options)
}

async function _tryReadResponseBody({
    r,
    options,
    url,
}: {
    r: Response
    options: NetworkRecordOptions
    url: string | URL | RequestInfo
}): Promise<string> {
    const cannotReadBodyReason: string | null = _checkForCannotReadResponseBody({ r, options, url })
    if (!isNull(cannotReadBodyReason)) {
        return Promise.resolve(cannotReadBodyReason)
    }

    return _readBody(r, options)
}

// Preserve the pre-#5200 wrapper unless the private init option explicitly opts in.
// Keep this path unchanged: publishing a new unversioned recorder must not opt customers in.
function initLegacyFetchObserver(
    cb: networkCallback,
    win: IWindow,
    options: Required<NetworkRecordOptions>
): listenerHandler {
    if (!options.initiatorTypes.includes('fetch')) {
        return () => {
            //
        }
    }
    const recordRequestHeaders = shouldRecordHeaders('request', options.recordHeaders)
    const recordResponseHeaders = shouldRecordHeaders('response', options.recordHeaders)

    // oxlint-disable-next-line typescript/ban-ts-comment
    // @ts-ignore
    const restorePatch = patch(win, 'fetch', (originalFetch: typeof fetch) => {
        return async function (url: URL | RequestInfo, init?: RequestInit | undefined) {
            // Constructing the capture Request happens _before_ we delegate to the original fetch, so
            // if it throws (e.g. a URL/method the host application would have handled) we must not let
            // that exception escape and misattribute a failure to session replay. Degrade gracefully and
            // let the original request still proceed.
            let req: Request
            try {
                // check IE earlier than this, we only initialize if Request is present
                req = new Request(url, init)
            } catch (e) {
                logger.error('Failed to instrument fetch for network capture', e)
                return originalFetch(url, init)
            }
            let res: Response | undefined
            const networkRequest: Partial<CapturedNetworkRequest> = {}
            let start: number | undefined
            let end: number | undefined

            try {
                // Recording the request headers/body must never prevent the host's fetch from running,
                // so failures here are swallowed and we fall through to the original request below.
                try {
                    const requestHeaders: Headers = {}
                    req.headers.forEach((value: string, header: string | number) => {
                        requestHeaders[header] = value
                    })
                    if (recordRequestHeaders) {
                        networkRequest.requestHeaders = requestHeaders
                    }
                    // Check the caller-supplied body, not req.body: Request normalizes all non-null bodies
                    // to a ReadableStream, but only an original ReadableStream would be locked by req.clone().text().
                    const requestBodyIsReadableStream = isReadableStreamBody(init?.body)
                    if (
                        !requestBodyIsReadableStream &&
                        shouldRecordBody({
                            type: 'request',
                            headers: requestHeaders,
                            url,
                            recordBody: options.recordBody,
                        })
                    ) {
                        networkRequest.requestBody = await _tryReadRequestBody({ r: req, options, url })
                    }
                } catch (e) {
                    logger.error('Failed to record fetch request for network capture', e)
                }

                start = win.performance.now()
                // Use `req` for recording metadata/body only. For fetch(url, init), do not pass this internally-created
                // Request downstream: it exposes request.body as a ReadableStream, and wrappers that forward that body
                // can trigger Safari's "ReadableStream uploading is not supported" error. For fetch(Request), we must
                // pass the cloned Request because constructing `req` may consume the original Request body.
                res = isRequest(url) ? await originalFetch(req) : await originalFetch(url, init)
                end = win.performance.now()

                try {
                    const responseHeaders: Headers = {}
                    res.headers.forEach((value: string, header: string | number) => {
                        responseHeaders[header] = value
                    })
                    if (recordResponseHeaders) {
                        networkRequest.responseHeaders = responseHeaders
                    }
                    if (
                        shouldRecordBody({
                            type: 'response',
                            headers: responseHeaders,
                            url,
                            recordBody: options.recordBody,
                        })
                    ) {
                        networkRequest.responseBody = await _tryReadResponseBody({ r: res, options, url })
                    }
                } catch (e) {
                    logger.error('Failed to record fetch response for network capture', e)
                }

                return res
            } finally {
                getRequestPerformanceEntry(win, 'fetch', req.url, start, end)
                    .then((entry) => {
                        const requests = prepareRequest(win, {
                            entry,
                            method: req.method,
                            status: res?.status,
                            networkRequest,
                            start,
                            end,
                            url: req.url,
                            initiatorType: 'fetch',
                        })
                        cb({ requests })
                    })
                    .catch(() => {
                        //
                    })
            }
        }
    })
    return () => {
        restorePatch()
    }
}

function initFetchObserver(
    cb: networkCallback,
    win: IWindow,
    options: Required<NetworkRecordOptions>
): listenerHandler {
    if (!options.initiatorTypes.includes('fetch')) {
        return () => {
            //
        }
    }
    const recordRequestHeaders = shouldRecordHeaders('request', options.recordHeaders)
    const recordResponseHeaders = shouldRecordHeaders('response', options.recordHeaders)

    // oxlint-disable-next-line typescript/ban-ts-comment
    // @ts-ignore
    const restorePatch = patch(win, 'fetch', (originalFetch: typeof fetch) => {
        return function (url: URL | RequestInfo, init?: RequestInit | undefined) {
            // Constructing the capture Request happens _before_ we delegate to the original fetch, so
            // if it throws (e.g. a URL/method the host application would have handled) we must not let
            // that exception escape and misattribute a failure to session replay. Degrade gracefully and
            // let the original request still proceed.
            let req: Request
            try {
                // check IE earlier than this, we only initialize if Request is present
                req = new Request(url, init)
            } catch (e) {
                logger.error('Failed to instrument fetch for network capture', e)
                try {
                    // oxlint-disable-next-line compat/compat
                    return Promise.resolve(originalFetch(url, init))
                } catch (fetchError) {
                    // oxlint-disable-next-line compat/compat
                    return new Promise((_resolve, reject) => reject(fetchError))
                }
            }
            const networkRequest: Partial<CapturedNetworkRequest> = {}
            let start: number | undefined
            let end: number | undefined

            // Start body capture without awaiting it. The host fetch must be invoked in the application's
            // synchronous call stack so a native rejection retains the application call site.
            // Body capture must reach req.clone() before its first yield: downstream fetch can consume req
            // immediately for Request inputs, making any later clone fail.
            const requestCapture = (async () => {
                try {
                    const requestHeaders: Headers = {}
                    req.headers.forEach((value: string, header: string | number) => {
                        requestHeaders[header] = value
                    })
                    if (recordRequestHeaders) {
                        networkRequest.requestHeaders = requestHeaders
                    }
                    // Check the caller-supplied body, not req.body: Request normalizes all non-null bodies
                    // to a ReadableStream, but only an original ReadableStream would be locked by req.clone().text().
                    const requestBodyIsReadableStream = isReadableStreamBody(init?.body)
                    if (
                        !requestBodyIsReadableStream &&
                        shouldRecordBody({
                            type: 'request',
                            headers: requestHeaders,
                            url,
                            recordBody: options.recordBody,
                        })
                    ) {
                        networkRequest.requestBody = await _tryReadRequestBody({ r: req, options, url })
                    }
                } catch (e) {
                    logger.error('Failed to record fetch request for network capture', e)
                }
            })()

            const captureResponse = async (res: Response): Promise<void> => {
                try {
                    const responseHeaders: Headers = {}
                    res.headers.forEach((value: string, header: string | number) => {
                        responseHeaders[header] = value
                    })
                    if (recordResponseHeaders) {
                        networkRequest.responseHeaders = responseHeaders
                    }
                    if (
                        shouldRecordBody({
                            type: 'response',
                            headers: responseHeaders,
                            url,
                            recordBody: options.recordBody,
                        })
                    ) {
                        networkRequest.responseBody = await _tryReadResponseBody({ r: res, options, url })
                    }
                } catch (e) {
                    logger.error('Failed to record fetch response for network capture', e)
                }
            }

            const captureTiming = (res?: Response): Promise<void> =>
                getRequestPerformanceEntry(win, 'fetch', req.url, start, end).then((entry) => {
                    const requests = prepareRequest(win, {
                        entry,
                        method: req.method,
                        status: res?.status,
                        networkRequest,
                        start,
                        end,
                        url: req.url,
                        initiatorType: 'fetch',
                    })
                    cb({ requests })
                })

            try {
                start = win.performance.now()
            } catch {
                // Missing timing data must not prevent the host fetch.
            }
            let fetchPromise: Promise<Response>
            try {
                // Use `req` for recording metadata/body only. For fetch(url, init), do not pass this internally-created
                // Request downstream: it exposes request.body as a ReadableStream, and wrappers that forward that body
                // can trigger Safari's "ReadableStream uploading is not supported" error. For fetch(Request), we must
                // pass the cloned Request because constructing `req` may consume the original Request body.
                fetchPromise = isRequest(url) ? originalFetch(req) : originalFetch(url, init)
            } catch (e) {
                // The previous async wrapper converted synchronous downstream throws into rejected promises.
                // oxlint-disable-next-line compat/compat
                fetchPromise = new Promise((_resolve, reject) => reject(e))
            }

            // Attach both handlers immediately so a fast rejection is always observed while request body capture
            // finishes. Calling the host fetch above without first yielding preserves the application's call site.
            // oxlint-disable-next-line compat/compat
            const fetchResult = Promise.resolve(fetchPromise).then(
                (response) => {
                    try {
                        end = win.performance.now()
                    } catch {
                        // Missing timing data must not affect the response.
                    }
                    return { status: 'fulfilled' as const, response }
                },
                (error) => ({ status: 'rejected' as const, error })
            )

            return (async () => {
                let response: Response | undefined
                try {
                    await requestCapture
                    const result = await fetchResult
                    if (result.status === 'rejected') {
                        throw result.error
                    }
                    response = result.response
                    await captureResponse(response)
                    return response
                } finally {
                    void captureTiming(response).catch(() => {
                        // Recording failures must never affect the host fetch or create unhandled rejections.
                    })
                }
            })()
        }
    })
    return () => {
        restorePatch()
    }
}

let initialisedHandler: listenerHandler | null = null

function initNetworkObserver(
    callback: networkCallback,
    win: IWindow, // top window or in an iframe
    options: NetworkPluginOptions
): listenerHandler {
    if (!('performance' in win)) {
        return () => {
            //
        }
    }

    if (initialisedHandler) {
        logger.warn('Network observer already initialised, doing nothing')
        return () => {
            // the first caller should already have this handler and will be responsible for teardown
        }
    }

    const networkOptions = (
        options ? Object.assign({}, defaultNetworkOptions, options) : defaultNetworkOptions
    ) as Required<NetworkRecordOptions> & NetworkPluginOptions

    let active = true
    let maskingFailureLogged = false
    const cb: networkCallback = (data) => {
        // Body reads and timing lookups can finish after this observer is replaced.
        if (!active) {
            return
        }
        const requests: CapturedNetworkRequest[] = []
        let parentRequestDropped = false
        data.requests.forEach((request) => {
            const isServerTiming = request.entryType === 'serverTiming'

            // Server timings are emitted immediately after their resource or navigation entry.
            // If a parent is dropped (i.e. a PostHog ingestion request), derived timings must too or an endless capture loop ensues.
            if (isServerTiming && parentRequestDropped) {
                return
            }

            let maskedRequest: CapturedNetworkRequest | null | undefined
            try {
                maskedRequest = networkOptions.maskRequestFn(request)
            } catch {
                if (!maskingFailureLogged) {
                    maskingFailureLogged = true
                    logger.warn(
                        'Network capture masking callback failed; dropping the record. Further masking failures will not be logged for this observer.'
                    )
                }
                if (!isServerTiming) {
                    parentRequestDropped = true
                }
                return
            }
            if (!isServerTiming) {
                // A null-filtered initial parent is replaced by a strict URL-less fallback so replay keeps its
                // required timing metadata. Treat that fallback as dropped for derived server timings, which
                // can still contain customer-controlled names and durations.
                parentRequestDropped = !maskedRequest || isInitialMaskFallback(maskedRequest)
            }
            if (maskedRequest) {
                requests.push(maskedRequest)
            }
        })

        if (requests.length > 0) {
            callback({ ...data, requests })
        }
    }
    const performanceObserver = initPerformanceObserver(cb, win, networkOptions)

    // only wrap fetch and xhr if headers or body are being recorded
    const wrapsNetworkPrimitives = networkOptions.recordHeaders || networkOptions.recordBody

    // initialisedHandler is shared by every frame being recorded, so a frame that captures
    // nothing must leave it for a frame that can, or one degraded frame silences the page
    if (!performanceObserver && !wrapsNetworkPrimitives) {
        active = false
        return noopHandler
    }

    let xhrObserver: listenerHandler = () => {}
    let fetchObserver: listenerHandler = () => {}
    if (wrapsNetworkPrimitives) {
        xhrObserver = initXhrObserver(cb, win, networkOptions)
        fetchObserver =
            networkOptions.captureFetchSynchronously === true
                ? initFetchObserver(cb, win, networkOptions)
                : initLegacyFetchObserver(cb, win, networkOptions)
    }

    initialisedHandler = () => {
        active = false
        performanceObserver?.()
        xhrObserver()
        fetchObserver()
        initialisedHandler = null
    }
    return initialisedHandler
}

// use the plugin name so that when this functionality is adopted into rrweb
// we can remove this plugin and use the core functionality with the same data
export const NETWORK_PLUGIN_NAME = 'rrweb/network@1'

// TODO how should this be typed?
// oxlint-disable-next-line typescript/ban-ts-comment
// @ts-ignore
export const getRecordNetworkPlugin: (options?: NetworkPluginOptions) => RecordPlugin = (options) => {
    return {
        name: NETWORK_PLUGIN_NAME,
        observer: initNetworkObserver,
        options: options,
    }
}

// rrweb/networ@1 ends
