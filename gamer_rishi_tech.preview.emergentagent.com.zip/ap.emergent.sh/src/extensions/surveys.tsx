import { type JSX, type RefObject, render, Fragment } from 'preact'
import { useContext, useEffect, useMemo, useRef, useState } from 'preact/hooks'
import { PostHog } from '../posthog-core'
import {
    DisplaySurveyPopoverOptions,
    Survey,
    SurveyCallback,
    SurveyEventName,
    SurveyEventProperties,
    SurveyPosition,
    SurveyQuestion,
    SurveyQuestionBranchingType,
    SurveyQuestionType,
    SurveyResponseValue,
    SurveySchedule,
    SurveyTabPosition,
    SurveyType,
    SurveyWidgetType,
    SurveyWithTypeAndAppearance,
} from '../posthog-surveys-types'
import { addEventListener } from '@posthog/browser-common/utils/general-utils'
import { document as _document, window as _window } from '@posthog/browser-common/utils/globals'
import {
    doesSurveyActivateByAction,
    doesSurveyActivateByEvent,
    IN_APP_SURVEY_TYPES,
    isCapturingEnabled,
    isSurveyIterationBased,
    isSurveyRunning,
    SURVEY_LOGGER as logger,
    SURVEY_CAPTURING_DISABLED,
} from '../utils/survey-utils'
import { isArray, isNull, isNumber, isUndefined } from '@posthog/core'
import { recordSurveyAnswer } from '@posthog/core/surveys'
import { Properties } from '../types'
import { FeatureFlagsExtension } from '../extension-tokens'
import type { PostHogFeatureFlags } from '../posthog-featureflags'
import { SURVEYS } from '../constants'
import { uuidv7 } from '@posthog/browser-common/utils/uuidv7'
import { ConfirmationMessage } from './surveys/components/ConfirmationMessage'
import { IntroScreen } from './surveys/components/IntroScreen'
import { Cancel } from './surveys/components/QuestionHeader'
import {
    CommonQuestionProps,
    LinkQuestion,
    MultipleChoiceQuestion,
    OpenTextQuestion,
    RatingQuestion,
} from './surveys/components/QuestionTypes'
import {
    canActivateRepeatedly,
    retrieveSurveyShadow,
    defaultSurveyAppearance,
    dismissedSurveyEvent,
    clearAllInMemoryInProgressSurveyState,
    clearInProgressSurveyState,
    doesSurveyDeviceTypesMatch,
    doesSurveyMatchSelector,
    doesSurveyUrlMatch,
    getDisplayOrderQuestions,
    getQuestionOrder,
    getInProgressSurveyState,
    getSurveyContainerClass,
    getSurveyResponseKey,
    getSurveySeen,
    hasWaitPeriodPassed,
    isSurveyInProgress,
    sendSurveyEvent,
    sendSurveyAbandonedEvent,
    setInProgressSurveyState,
    SurveyContext,
    getSurveyStylesheet,
    addSurveyCSSVariablesToElement,
    getPopoverPosition,
} from './surveys/surveys-extension-utils'
import {
    extractPrefillParamsFromUrl,
    convertPrefillToResponses,
    calculatePrefillStartIndex,
} from '../utils/survey-url-prefill'
import { getNextSurveyStep } from '../utils/survey-branching'
import { applySurveyTranslationForUser } from '../utils/survey-translations'

// Re-export for surveys-preview entrypoint
export { getNextSurveyStep }

/**
 * `previewPageIndex` sentinel for the intro screen — the leading mirror of the confirmation
 * page's `survey.questions.length` sentinel. Also serves as a capability marker for the main
 * app: bundles without this export cannot render the intro screen preview.
 */
export const INTRO_SCREEN_PREVIEW_INDEX = -1

// We cast the types here which is dangerous but protected by the top level generateSurveys call
const window = _window as Window & typeof globalThis
const document = _document as Document

const DISPATCH_FEEDBACK_WIDGET_EVENT = 'ph:show_survey_widget'
const WIDGET_LISTENER_ATTRIBUTE = 'PHWidgetSurveyClickListener'

const SURVEY_NEXT_TO_TRIGGER_PARAMS = {
    ESTIMATED_MIN_HEIGHT: 250,
    HORIZONTAL_PADDING: 20,
    TRIGGER_SPACING: 12,
} as const

function getNextToTriggerPosition(target: HTMLElement, surveyWidth: number): JSX.CSSProperties | null {
    try {
        const buttonRect = target.getBoundingClientRect()
        const viewportHeight = window.innerHeight
        const viewportWidth = window.innerWidth
        const estimatedMinSurveyHeight = SURVEY_NEXT_TO_TRIGGER_PARAMS.ESTIMATED_MIN_HEIGHT
        const buttonCenterX = buttonRect.left + buttonRect.width / 2
        let left = buttonCenterX - surveyWidth / 2
        const horizontalPadding = SURVEY_NEXT_TO_TRIGGER_PARAMS.HORIZONTAL_PADDING
        if (left + surveyWidth > viewportWidth - horizontalPadding) {
            left = viewportWidth - surveyWidth - horizontalPadding
        }
        if (left < horizontalPadding) {
            left = horizontalPadding
        }
        const spacing = SURVEY_NEXT_TO_TRIGGER_PARAMS.TRIGGER_SPACING
        const spaceBelow = viewportHeight - buttonRect.bottom
        const spaceAbove = buttonRect.top
        const showAbove = spaceBelow < estimatedMinSurveyHeight && spaceAbove > spaceBelow

        return {
            position: 'fixed',
            top: showAbove ? 'auto' : `${buttonRect.bottom + spacing}px`,
            left: `${left}px`,
            right: 'auto',
            bottom: showAbove ? `${viewportHeight - buttonRect.top + spacing}px` : 'auto',
            zIndex: defaultSurveyAppearance.zIndex,
        } satisfies JSX.CSSProperties
    } catch (error) {
        logger.warn('Failed to calculate trigger position:', error)
        return null
    }
}

// Keep in sync with posthog/constants.py on main repo
const SURVEY_TARGETING_FLAG_PREFIX = 'survey-targeting-'

export class SurveyManager {
    private _posthog: PostHog
    private _surveyInFocus: string | null
    private _surveyTimeouts: Map<string, ReturnType<Window['setTimeout']>> = new Map()
    private _widgetSelectorListeners: Map<string, { element: Element; listener: EventListener; survey: Survey }> =
        new Map()
    private _renderedTabWidgets: Map<string, Survey> = new Map()
    private _renderedTargets: Map<ShadowRoot, Element> = new Map()
    private _prefillHandledSurveys: Set<string> = new Set()
    private _automaticDisplayDispose?: () => void
    private _currentLanguage: string | null = null
    private _surveyIsRendered: boolean = false
    private _languageChangeListener: (() => void) | null = null
    private _unsubscribeFeatureFlags: (() => void) | null = null
    private _surveyPopupProps: SurveyPopupProps | null = null
    // Preserved so a language change can re-derive the survey from the fresh translation and
    // re-apply the same display overrides, rather than reusing the overridden survey from the
    // original render (which would go stale if the underlying survey definition changes).
    private _displayOptions: DisplaySurveyPopoverOptions | undefined
    private _loggedFeatureFlagsDisabledWarning: boolean = false

    constructor(posthog: PostHog) {
        this._posthog = posthog
        // This is used to track the survey that is currently in focus. We only show one survey at a time.
        this._surveyInFocus = null

        this._languageChangeListener = () => this._onLanguageChange()
        addEventListener(window, 'languagechange', this._languageChangeListener)

        // Re-translate when identify() or setPersonPropertiesForFlags() reloads flags,
        // which may have updated the 'language' person property.
        this._unsubscribeFeatureFlags = posthog.onFeatureFlags(() => this._onLanguageChange())
    }

    private _onLanguageChange(): void {
        if (isNull(this._surveyInFocus)) {
            return
        }
        const surveys = this._posthog.get_property(SURVEYS) as Survey[] | undefined
        const survey = surveys?.find((s) => s.id === this._surveyInFocus)
        if (!survey) {
            return
        }
        const { survey: translatedSurvey, language: newLanguage } = this._translateSurveyForRendering(survey)
        if (newLanguage === this._currentLanguage) {
            return
        }
        this._currentLanguage = newLanguage
        if (!this._surveyIsRendered) {
            // Nothing on screen yet (survey is still counting down its popup delay) — just
            // record the language flip. renderAfterDelay re-translates from scratch when the
            // delay elapses, so it always picks up whatever _currentLanguage ends up being,
            // rather than the language in effect when the delay started.
            return
        }
        // Translate from the raw survey (so a language with no translation still falls back to
        // the original), then re-apply the same display overrides handlePopoverSurvey used —
        // otherwise a survey shown via displaySurvey(id, { position, selector }) would snap back
        // to its configured appearance on the first language change.
        const overriddenSurvey = this._applyDisplayOverrides(translatedSurvey, this._displayOptions)
        const { shadow } = retrieveSurveyShadow(overriddenSurvey, this._posthog)
        render(
            <SurveyPopup
                {...this._surveyPopupProps}
                posthog={this._posthog}
                survey={overriddenSurvey}
                removeSurveyFromFocus={this._removeSurveyFromFocus}
                surveyLanguage={newLanguage}
            />,
            shadow
        )
    }

    private get _featureFlags(): PostHogFeatureFlags | undefined {
        // A newly deployed surveys bundle can still be loaded by an older cached core.
        return this._posthog.getExtension?.(FeatureFlagsExtension) ?? this._posthog.featureFlags
    }

    // apply overrides for position / selector (needed for thumb surveys)
    private _applyDisplayOverrides(survey: Survey, options?: DisplaySurveyPopoverOptions): Survey {
        return options?.position || options?.selector
            ? {
                  ...survey,
                  appearance: {
                      ...survey.appearance,
                      ...(options.position && { position: options.position }),
                      ...(options.selector && { widgetSelector: options.selector }),
                  },
              }
            : survey
    }

    public handlePageUnload = (): void => {
        // we don't use getSurveys to avoid adding extra API calls here.
        // if no surveys are cached, there's nothing to do anyways
        const surveys = this._posthog.get_property(SURVEYS) as Survey[] | undefined
        if (!surveys) {
            return
        }
        for (const survey of surveys) {
            if (isSurveyInProgress(survey)) {
                sendSurveyAbandonedEvent(survey, this._posthog)
            }
        }
    }

    private _clearSurveyTimeout(surveyId: string) {
        const timeout = this._surveyTimeouts.get(surveyId)
        if (timeout) {
            clearTimeout(timeout)
            this._surveyTimeouts.delete(surveyId)
        }
    }

    /**
     * cancel a "pending" survey, i.e. one that is waiting to be displayed in
     * the _surveyTimeouts queue
     */
    public cancelSurvey(surveyId: string): void {
        // only works for surveys in the _surveyTimeouts queue...
        if (!this._surveyTimeouts.has(surveyId)) {
            return
        }

        logger.info(`Cancelled pending survey ${surveyId}`)
        this._clearSurveyTimeout(surveyId)

        // release focus - it was claimed when the delay timer started.
        // "focus" != "survey is displayed"
        if (this._surveyInFocus === surveyId) {
            this._surveyInFocus = null
            // Mirror _removeSurveyFromFocus's cleanup: a cancelled survey never rendered, so
            // there's no display state to keep around for it either.
            this._currentLanguage = null
            this._surveyIsRendered = false
            this._surveyPopupProps = null
            this._displayOptions = undefined
        }
    }

    /**
     * Called by the core on reset(). It cannot clear the map itself: survey-utils compiles into
     * both the core and this extension, so a core-side clear reaches only its own unused copy.
     */
    public clearInMemoryInProgressSurveyState(): void {
        clearAllInMemoryInProgressSurveyState()
    }

    public setAutomaticDisplayDispose(dispose: () => void): void {
        this._automaticDisplayDispose = dispose
    }

    public dispose(): void {
        this._automaticDisplayDispose?.()
        this._automaticDisplayDispose = undefined
        if (this._languageChangeListener) {
            window.removeEventListener('languagechange', this._languageChangeListener)
            this._languageChangeListener = null
        }
        if (this._unsubscribeFeatureFlags) {
            this._unsubscribeFeatureFlags()
            this._unsubscribeFeatureFlags = null
        }
        this._surveyTimeouts.forEach((_timeout, surveyId) => this._clearSurveyTimeout(surveyId))
        this._widgetSelectorListeners.forEach((_listener, surveyId) => this._detachWidgetSelectorListener(surveyId))
        this._renderedTargets.forEach((container, target) => {
            render(null, target)
            container?.remove()
        })
        this._renderedTargets.clear()
        this._renderedTabWidgets.clear()
        this._surveyInFocus = null
    }

    /**
     * `resumeDelayFromActivation` is internal to the display loop: a survey armed by an
     * event/action trigger resumes its popup delay from when the trigger fired, so navigating
     * mid-delay does not restart the countdown. An explicit `displaySurvey()` call carries its own
     * `ignoreDelay` option instead, so it must always honor the full configured delay.
     */
    public handlePopoverSurvey = (
        surveyParam: Survey,
        options?: DisplaySurveyPopoverOptions,
        { resumeDelayFromActivation = false }: { resumeDelayFromActivation?: boolean } = {}
    ): void => {
        if (!isCapturingEnabled(this._posthog)) {
            return
        }
        const { survey: translatedSurvey, language: surveyLanguage } = this._translateSurveyForRendering(surveyParam)
        this._currentLanguage = surveyLanguage
        this._surveyPopupProps = null
        this._displayOptions = options

        const survey = this._applyDisplayOverrides(translatedSurvey, options)

        this._clearSurveyTimeout(survey.id)

        const { properties, initialResponses } = options ?? {}
        const hasPrefillData = initialResponses && Object.keys(initialResponses).length > 0
        const isSurveyCompleted = hasPrefillData
            ? this._handleInitialResponses(survey, initialResponses, properties, surveyLanguage)
            : false

        // if the survey is done (from prefill) and there is no thank-you, we can break early
        if (isSurveyCompleted && !survey.appearance?.displayThankYouMessage) {
            return
        }

        this._addSurveyToFocus(survey)

        // Calculate position style for NextToTrigger positioning
        let positionStyle: JSX.CSSProperties = {}
        if (survey.appearance?.position === SurveyPosition.NextToTrigger && survey.appearance?.widgetSelector) {
            const targetElement = document.querySelector(survey.appearance.widgetSelector) as HTMLElement | null
            if (targetElement) {
                positionStyle =
                    getNextToTriggerPosition(
                        targetElement,
                        parseInt(survey.appearance?.maxWidth || defaultSurveyAppearance.maxWidth)
                    ) || {}
            }
        }

        const delaySeconds = survey.appearance?.surveyPopupDelaySeconds || 0
        const { shadow } = retrieveSurveyShadow(survey, this._posthog)
        this._renderedTargets.set(shadow, shadow.host)

        const surveyPopupProps: SurveyPopupProps = {
            posthog: this._posthog,
            survey: survey,
            removeSurveyFromFocus: this._removeSurveyFromFocus,
            properties: properties,
            style: positionStyle,
            isSurveyCompleted: isSurveyCompleted,
            skipShownEvent: options?.skipShownEvent,
            surveyLanguage,
        }
        this._surveyPopupProps = surveyPopupProps

        if (delaySeconds <= 0) {
            this._surveyIsRendered = true
            return render(<SurveyPopup {...surveyPopupProps} />, shadow)
        }

        // rendering with surveyPopupDelaySeconds = 0 because the delay is handled here, not in the popup
        const renderAfterDelay = () => {
            this._surveyIsRendered = true
            // Re-translate from the original survey rather than reusing the `survey` captured
            // when the delay started — the display language can change while the delay counts
            // down (see _onLanguageChange), and without this the popup would render in
            // whatever language was active at the start of the delay instead of the current one.
            const { survey: freshlyTranslated, language: freshLanguage } =
                this._translateSurveyForRendering(surveyParam)
            this._currentLanguage = freshLanguage
            const freshSurvey = this._applyDisplayOverrides(freshlyTranslated, options)
            const freshPopupProps: SurveyPopupProps = {
                ...surveyPopupProps,
                survey: freshSurvey,
                surveyLanguage: freshLanguage,
            }
            this._surveyPopupProps = freshPopupProps
            render(
                <SurveyPopup
                    {...freshPopupProps}
                    survey={{
                        ...freshSurvey,
                        appearance: {
                            ...freshSurvey.appearance,
                            surveyPopupDelaySeconds: 0,
                        },
                    }}
                />,
                shadow
            )
        }

        // Re-check the full display predicate, not just the URL: eligibility can change
        // while the delay runs down (e.g. identify() reloads flags and the internal targeting flag
        // flips to false, or the person opts out of capturing), and we must not show a survey that
        // is no longer eligible by the time the delay elapses.
        const renderIfStillEligible = () => {
            if (!isCapturingEnabled(this._posthog) || !this._shouldDisplaySurvey(survey)) {
                logger.info(`Survey ${survey.id} no longer eligible when its display delay elapsed; not displaying`)
                return this._removeSurveyFromFocus(survey)
            }
            renderAfterDelay()
        }

        // Resume the delay across navigations. An event/action trigger records when it fired
        // (persisted, session-scoped), so the remaining wait is measured from that instead of
        // restarting a fresh countdown on every page load — otherwise a user who keeps navigating
        // never lets the delay elapse and never sees the survey. Without a recorded activation
        // (e.g. a survey shown on an `always`/wait-period basis rather than a trigger) we fall
        // back to the full delay, matching the previous behaviour.
        const activatedAt = resumeDelayFromActivation
            ? this._posthog.surveys?._surveyEventReceiver?.getActivationTimestamp?.(survey.id)
            : undefined
        // Clamp the elapsed time at 0 so a clock that moved backwards after the activation was
        // stamped (NTP correction, VM suspend/resume) cannot stretch the wait past the delay.
        const elapsedMs = isNumber(activatedAt) ? Math.max(0, Date.now() - activatedAt) : 0
        const remainingMs = Math.max(0, delaySeconds * 1000 - elapsedMs)

        if (remainingMs <= 0) {
            // The delay already elapsed on an earlier page load; show now, if still eligible.
            return renderIfStillEligible()
        }

        const timeoutId = window.setTimeout(() => {
            // remove survey to keep `_surveyTimeouts` as a true list of "pending" surveys
            this._surveyTimeouts.delete(survey.id)

            renderIfStillEligible()
        }, remainingMs)
        this._surveyTimeouts.set(survey.id, timeoutId)
    }

    private _handleWidget = (survey: Survey): void => {
        const { survey: translatedSurvey, language: surveyLanguage } = this._translateSurveyForRendering(survey)
        // Ensure widget container exists if it doesn't
        const { shadow, isNewlyCreated } = retrieveSurveyShadow(translatedSurvey, this._posthog)
        this._renderedTargets.set(shadow, shadow.host)
        if (survey.appearance?.widgetType === SurveyWidgetType.Tab) {
            this._renderedTabWidgets.set(survey.id, survey)
        }

        // If the widget is already rendered, do nothing. Otherwise the widget will be re-rendered every second
        if (!isNewlyCreated) {
            return
        }

        render(
            <FeedbackWidget
                posthog={this._posthog}
                survey={translatedSurvey}
                surveyLanguage={surveyLanguage}
                key={survey.id}
            />,
            shadow
        )
    }

    // Detach the tracked click listener (and its marker attribute) from the trigger element for a
    // survey, without touching the rendered survey DOM. Safe to call while a survey is open — it
    // only cleans up the trigger wiring, which is what an element swap needs.
    private _detachWidgetSelectorListener = (surveyId: string): void => {
        const existing = this._widgetSelectorListeners.get(surveyId)
        if (existing) {
            existing.element.removeEventListener('click', existing.listener)
            existing.element.removeAttribute(WIDGET_LISTENER_ATTRIBUTE)
            this._widgetSelectorListeners.delete(surveyId)
            logger.info(`Removed click listener for survey ${surveyId}`)
        }
    }

    private _removeWidgetSelectorListener = (survey: Pick<Survey, 'id' | 'type' | 'appearance'>): void => {
        // Defer teardown while the survey is open (issue #2036). The trigger element may have
        // been unmounted mid-survey — e.g. a dropdown/menu that hosts it was closed — and tearing
        // the survey down here would make the open survey abruptly vanish. Keep it in place; the
        // next display poll retries this cleanup once the user has closed the survey.
        if (this._isWidgetSurveyOpen(survey)) {
            return
        }
        this._removeSurveyFromDom(survey)
        this._detachWidgetSelectorListener(survey.id)
    }

    // A tab widget draws its own trigger, so it stays on screen until something removes it. The
    // display poll no longer matches a survey once it becomes ineligible, which leaves the trigger
    // as a live entry point to a survey whose response would be dropped.
    private _removeTabWidget = (survey: Survey): void => {
        // Same deferral as the selector widget: a teardown while the survey is open would make it
        // vanish under the person. The next display poll retries.
        if (this._isWidgetSurveyOpen(survey)) {
            return
        }
        this._removeSurveyFromDom(survey)
        this._renderedTabWidgets.delete(survey.id)
    }

    private _isWidgetSurveyOpen = (survey: Pick<Survey, 'id' | 'type' | 'appearance'>): boolean => {
        try {
            // The survey popup (`.ph-survey`) is only present in the shadow root while the survey
            // is actually open; when only the widget/trigger is mounted it is absent.
            const shadowContainer = document.querySelector(getSurveyContainerClass(survey, true))
            return !!shadowContainer?.shadowRoot?.querySelector('.ph-survey')
        } catch {
            return false
        }
    }

    private _manageWidgetSelectorListener = (survey: Survey, selector: string): void => {
        const currentElement = document.querySelector(selector)
        const existingListenerData = this._widgetSelectorListeners.get(survey.id)

        if (!currentElement) {
            if (existingListenerData) {
                this._removeWidgetSelectorListener(survey)
            }
            return
        }

        this._handleWidget(survey)

        if (existingListenerData) {
            // Listener exists, check if element changed
            if (currentElement !== existingListenerData.element) {
                logger.info(`Selector element changed for survey ${survey.id}. Re-attaching listener.`)
                // Detach the *old* element's listener directly. Routing this through
                // _removeWidgetSelectorListener would defer while the survey is open (to avoid
                // tearing down the open survey's DOM), leaking the old element's listener — and the
                // map entry that tracks it is overwritten just below, losing the only reference
                // needed to ever clean it up.
                this._detachWidgetSelectorListener(survey.id)
                // Continue to attach listener to the new element below
            } else {
                // Element is the same, listener already attached, do nothing
                return
            }
        }

        // Element found, and no listener attached (or it was just removed from old element)
        if (!currentElement.hasAttribute(WIDGET_LISTENER_ATTRIBUTE)) {
            const listener = (event: Event) => {
                event.stopPropagation() // Prevent bubbling

                const positionStyles =
                    survey.appearance?.position === SurveyPosition.NextToTrigger
                        ? getNextToTriggerPosition(
                              event.currentTarget as HTMLElement,
                              parseInt(survey.appearance?.maxWidth || defaultSurveyAppearance.maxWidth)
                          )
                        : {}

                window.dispatchEvent(
                    new CustomEvent(DISPATCH_FEEDBACK_WIDGET_EVENT, {
                        detail: { surveyId: survey.id, position: positionStyles },
                    })
                )
            }

            addEventListener(currentElement, 'click', listener)
            currentElement.setAttribute(WIDGET_LISTENER_ATTRIBUTE, 'true')
            this._widgetSelectorListeners.set(survey.id, { element: currentElement, listener, survey })
            logger.info(`Attached click listener for feedback button survey ${survey.id}`)
        }
    }

    /**
     * Sorts surveys by their appearance delay in ascending order. If a survey does not have an appearance delay,
     * it is considered to have a delay of 0.
     * @param surveys
     * @returns The surveys sorted by their appearance delay
     */
    private _sortSurveysByAppearanceDelay(surveys: Survey[]): Survey[] {
        return surveys.sort((a, b) => {
            const isSurveyInProgressA = isSurveyInProgress(a)
            const isSurveyInProgressB = isSurveyInProgress(b)
            if (isSurveyInProgressA && !isSurveyInProgressB) {
                return -1 // a comes before b (in progress surveys first)
            }
            if (!isSurveyInProgressA && isSurveyInProgressB) {
                return 1 // a comes after b (in progress surveys first)
            }
            const aIsAlways = a.schedule === SurveySchedule.Always
            const bIsAlways = b.schedule === SurveySchedule.Always

            if (aIsAlways && !bIsAlways) {
                return 1 // a comes after b
            }
            if (!aIsAlways && bIsAlways) {
                return -1 // a comes before b
            }
            // If both are Always or neither is Always, sort by delay
            return (a.appearance?.surveyPopupDelaySeconds || 0) - (b.appearance?.surveyPopupDelaySeconds || 0)
        })
    }

    public renderPopover = (survey: Survey): void => {
        if (!isCapturingEnabled(this._posthog)) {
            return
        }
        const { survey: translatedSurvey, language: surveyLanguage } = this._translateSurveyForRendering(survey)
        const { shadow } = retrieveSurveyShadow(translatedSurvey, this._posthog)
        this._renderedTargets.set(shadow, shadow.host)
        render(
            <SurveyPopup
                posthog={this._posthog}
                survey={translatedSurvey}
                removeSurveyFromFocus={this._removeSurveyFromFocus}
                surveyLanguage={surveyLanguage}
            />,
            shadow
        )
    }

    public renderSurvey = (survey: Survey, selector: Element, properties?: Properties): void => {
        if (!isCapturingEnabled(this._posthog)) {
            return
        }
        const { survey: translatedSurvey, language: surveyLanguage } = this._translateSurveyForRendering(survey)
        let isSurveyCompleted = false
        if (this._posthog.config?.surveys?.prefillFromUrl) {
            isSurveyCompleted = this._handleUrlPrefill(translatedSurvey, surveyLanguage, properties)
        }

        render(
            <SurveyPopup
                posthog={this._posthog}
                survey={translatedSurvey}
                removeSurveyFromFocus={this._removeSurveyFromFocus}
                isPopup={false}
                properties={properties}
                isSurveyCompleted={isSurveyCompleted}
                surveyLanguage={surveyLanguage}
            />,
            selector
        )
    }

    private _translateSurveyForRendering(survey: Survey): { survey: Survey; language: string | null } {
        // Rendering entry points accept the raw API survey. The translation helper is idempotent,
        // but keeping this central avoids each entry point growing its own language rules.
        return applySurveyTranslationForUser(survey, this._posthog)
    }

    private _handleUrlPrefill(survey: Survey, surveyLanguage?: string | null, properties?: Properties): boolean {
        // Only handle prefill once per survey session to avoid overwriting in-progress responses
        if (this._prefillHandledSurveys.has(survey.id)) {
            return false
        }

        const { params } = extractPrefillParamsFromUrl(window.location.search)

        if (Object.keys(params).length === 0) {
            return false
        }

        logger.info('[Survey Prefill] Detected URL prefill parameters')

        const result = this._processPrefillData(survey, params, surveyLanguage)
        if (!result) {
            return false
        }

        this._autoSubmitPrefilledResponses(survey, result, properties, surveyLanguage)

        // Mark this survey as having been prefilled
        this._prefillHandledSurveys.add(survey.id)

        return result.isSurveyCompleted
    }

    /**
     * On load, capture a response for prefilled questions only when:
     * 1) the survey is complete, OR
     * 2) partial responses are enabled AND the skipped questions were set to auto-submit.
     */
    private _autoSubmitPrefilledResponses(
        survey: Survey,
        result: NonNullable<ReturnType<SurveyManager['_processPrefillData']>>,
        properties?: Properties,
        surveyLanguage?: string | null
    ): void {
        const { responses, submissionId, isSurveyCompleted, skippedResponses } = result
        const shouldAutoSubmitPrefilled = Object.keys(skippedResponses).length > 0 && survey.enable_partial_responses
        if (shouldAutoSubmitPrefilled || isSurveyCompleted) {
            sendSurveyEvent({
                responses: isSurveyCompleted ? responses : skippedResponses,
                survey,
                surveySubmissionId: submissionId,
                posthog: this._posthog,
                isSurveyCompleted,
                properties,
                surveyLanguage,
            })
        }
    }

    /**
     * process prefilled responses for non-hosted surveys
     *
     * @returns boolean, true if the survey is completed
     */
    private _handleInitialResponses(
        survey: Survey,
        initialResponses: Record<number, SurveyResponseValue>,
        properties?: Properties,
        surveyLanguage?: string | null
    ): boolean {
        const prefillParams: { [key: number]: string[] } = {}
        for (const [indexStr, value] of Object.entries(initialResponses)) {
            const index = parseInt(indexStr)
            prefillParams[index] = isArray(value) ? value.map(String) : [String(value)]
        }

        logger.info('[Survey] Processing initial responses')

        const result = this._processPrefillData(survey, prefillParams, surveyLanguage)
        if (!result) {
            return false
        }

        this._autoSubmitPrefilledResponses(survey, result, properties, surveyLanguage)

        return result.isSurveyCompleted
    }

    private _processPrefillData(
        survey: Survey,
        prefillParams: Record<number, string[]>,
        surveyLanguage?: string | null
    ): {
        responses: Record<string, any>
        submissionId: string
        startQuestionIndex: number
        isSurveyCompleted: boolean
        skippedResponses: Record<string, any>
    } | null {
        try {
            const responses = convertPrefillToResponses(survey, prefillParams)

            if (Object.keys(responses).length === 0) {
                logger.warn('[Survey Prefill] No valid responses after conversion')
                return null
            }

            const submissionId = uuidv7()

            // calculate which question to start at based on prefilled questions
            const prefilledIndices = Object.keys(prefillParams).map((k) => parseInt(k, 10))
            const { startQuestionIndex, skippedResponses, skippedIndices } = calculatePrefillStartIndex(
                survey,
                prefilledIndices,
                responses
            )
            const isSurveyCompleted = startQuestionIndex >= survey.questions.length

            setInProgressSurveyState(survey, {
                surveySubmissionId: submissionId,
                responses: responses,
                lastQuestionIndex: startQuestionIndex,
                questionOrder: getQuestionOrder(survey.questions),
                // Mark auto-advanced questions visited so a manual submit doesn't prune their answers.
                visitedIndices: skippedIndices,
                surveyLanguage,
            })

            logger.info('[Survey Prefill] Stored prefilled responses in localStorage')

            return { responses, submissionId, startQuestionIndex, isSurveyCompleted, skippedResponses }
        } catch (error) {
            logger.error('[Survey Prefill] Error handling prefill:', error)
            return null
        }
    }

    private _isSurveyFeatureFlagEnabled(flagKey: string | null, flagVariant: string | undefined = undefined) {
        if (!flagKey) {
            return true
        }
        const featureFlags = this._featureFlags
        const isFeatureEnabled = !!featureFlags?.isFeatureEnabled(flagKey, {
            send_event: !flagKey.startsWith(SURVEY_TARGETING_FLAG_PREFIX),
        })
        let flagVariantCheck = true
        if (flagVariant) {
            const flagVariantValue = featureFlags?.getFeatureFlag(flagKey, { send_event: false })
            flagVariantCheck = flagVariantValue === flagVariant || flagVariant === 'any'
        }
        const enabled = isFeatureEnabled && flagVariantCheck
        if (!enabled) {
            this._warnIfFeatureFlagsDisabled(flagKey)
        }
        return enabled
    }

    private _warnIfFeatureFlagsDisabled(flagKey: string): void {
        if (this._loggedFeatureFlagsDisabledWarning || !this._posthog.config?.advanced_disable_feature_flags) {
            return
        }
        this._loggedFeatureFlagsDisabledWarning = true
        logger.warn(
            `Survey feature flag "${flagKey}" evaluated to false because advanced_disable_feature_flags is set. ` +
                'PostHog creates an internal targeting flag for almost every survey, so no survey can display while flags are disabled. ' +
                'To keep surveys working, replace advanced_disable_feature_flags with advanced_only_evaluate_survey_feature_flags, ' +
                'which evaluates survey flags only.'
        )
    }

    private _isSurveyConditionMatched(survey: Survey): boolean {
        if (!survey.conditions) {
            return true
        }
        return (
            doesSurveyUrlMatch(survey, this._posthog) &&
            doesSurveyDeviceTypesMatch(survey) &&
            doesSurveyMatchSelector(survey)
        )
    }

    private _internalFlagCheckSatisfied(survey: Survey): { satisfied: boolean; reason?: string } {
        // Repeatable and in-progress surveys intentionally bypass the internal targeting flag.
        if (canActivateRepeatedly(survey)) {
            return { satisfied: true }
        }

        // For every other survey the internal targeting flag is the "already answered this
        // iteration" gate. Its value is recomputed server-side once a response is recorded, but the
        // SDK serves the previous value from cache until the next /flags load. Trusting that stale
        // value on a revisit re-displays the survey and records a duplicate response, so wait until
        // flags have actually (re)loaded this session before relying on the internal targeting flag.
        //
        // Only iteration-based surveys need that wait: their stored seen state is keyed by iteration
        // and rolls over, leaving the flag as the sole duplicate gate. Any other survey keeps one
        // stable seen key that already blocks re-display, and waiting there costs real eligibility,
        // permanently so for a caller that asks once and never asks again.
        //
        // The gap this accepts: a response recorded on another device, or a cleared localStorage,
        // leaves no seen key here while this browser can still hold a cached enabled flag, so the
        // survey can display once more before the next /flags load corrects it. A zero-delay popover
        // is already rendered by then and no later evaluation withdraws it. Waiting on flags closes
        // that gap but drops every impression in the pre-flags window, which is the larger loss, so
        // do not widen this condition back out without replacing what it costs.
        if (
            survey.internal_targeting_flag_key &&
            isSurveyIterationBased(survey) &&
            !this._featureFlags?.hasLoadedFlags
        ) {
            this._warnIfFeatureFlagsDisabled(survey.internal_targeting_flag_key)
            return {
                satisfied: false,
                reason: 'Feature flags have not loaded yet; deferring internal targeting flag check',
            }
        }

        return { satisfied: this._isSurveyFeatureFlagEnabled(survey.internal_targeting_flag_key) }
    }

    public checkSurveyEligibility(survey: Survey): { eligible: boolean; reason?: string } {
        const eligibility = { eligible: true, reason: undefined as string | undefined }

        if (!isSurveyRunning(survey)) {
            eligibility.eligible = false
            eligibility.reason = `Survey is not running. It was completed on ${survey.end_date}`
            return eligibility
        }

        if (!IN_APP_SURVEY_TYPES.includes(survey.type)) {
            eligibility.eligible = false
            eligibility.reason = `Surveys of type ${survey.type} are never eligible to be shown in the app`
            return eligibility
        }

        const linkedFlagVariant = survey.conditions?.linkedFlagVariant
        if (!this._isSurveyFeatureFlagEnabled(survey.linked_flag_key, linkedFlagVariant)) {
            eligibility.eligible = false
            if (!linkedFlagVariant) {
                eligibility.reason = `Survey linked feature flag is not enabled`
            } else {
                eligibility.reason = `Survey linked feature flag is not enabled for variant ${linkedFlagVariant}`
            }
            return eligibility
        }

        if (!this._isSurveyFeatureFlagEnabled(survey.targeting_flag_key)) {
            eligibility.eligible = false
            eligibility.reason = `Survey targeting feature flag is not enabled`
            return eligibility
        }

        const internalFlagCheck = this._internalFlagCheckSatisfied(survey)
        if (!internalFlagCheck.satisfied) {
            eligibility.eligible = false
            eligibility.reason =
                internalFlagCheck.reason ??
                'Survey internal targeting flag is not enabled and survey cannot activate repeatedly and survey is not in progress'
            return eligibility
        }

        if (!hasWaitPeriodPassed(survey.conditions?.seenSurveyWaitPeriodInDays)) {
            eligibility.eligible = false
            eligibility.reason = `Survey wait period has not passed`
            return eligibility
        }

        if (getSurveySeen(survey)) {
            eligibility.eligible = false
            eligibility.reason = `Survey has already been seen and it can't be activated again`
            return eligibility
        }

        return eligibility
    }

    /**
     * PostHog's capture state, as an eligibility result. This is a prerequisite for any survey the
     * SDK renders itself, not one of the survey's display conditions: without it a person types an
     * answer, sees the confirmation, and `capture()` drops the `survey sent` event. So
     * `displaySurvey`'s `ignoreConditions` must not bypass it. `is_capturing()` is the same gate
     * `capture()` uses, so cookieless `on_reject` stays eligible.
     *
     * Deliberately kept out of `checkSurveyEligibility`: that also backs the public
     * `getActiveMatchingSurveys`, which custom integrations use to discover API surveys they
     * render themselves and record through their own backend (see `markSurveyAsSeen`). PostHog's
     * capture state says nothing about whether such a response can be recorded, so discovery
     * stays capture-independent.
     */
    public checkSurveyCaptureEligibility(): { eligible: boolean; reason?: string } {
        if (!isCapturingEnabled(this._posthog)) {
            return { eligible: false, reason: SURVEY_CAPTURING_DISABLED }
        }
        return { eligible: true }
    }

    /**
     * Eligibility for a survey the SDK renders and captures the response for itself: everything
     * `checkSurveyEligibility` checks, plus PostHog's capture state.
     */
    public checkSurveyDisplayEligibility(survey: Survey): { eligible: boolean; reason?: string } {
        const captureEligibility = this.checkSurveyCaptureEligibility()
        if (!captureEligibility.eligible) {
            return captureEligibility
        }
        return this.checkSurveyEligibility(survey)
    }

    /**
     * Renderability = display eligibility (running, type, flags, wait period, already-seen,
     * capturing) plus the survey's event/action activation trigger. Used by the programmatic
     * `canRenderSurvey` / `canRenderSurveyAsync` checks so they match the display loop.
     *
     * The trigger is intentionally kept out of `checkSurveyDisplayEligibility`: that method is
     * also used by the explicit `displaySurvey` path, and the trigger state only lives in memory
     * (a reload clears it, server-side events never set it). Gating eligibility on it would
     * make explicit `displaySurvey('id')` calls silently show nothing.
     */
    public checkSurveyRenderability(survey: Survey): { eligible: boolean; reason?: string } {
        const eligibility = this.checkSurveyDisplayEligibility(survey)
        if (eligibility.eligible && !this._hasActionOrEventTriggeredSurvey(survey)) {
            return { eligible: false, reason: `Survey event/action trigger has not been fired yet` }
        }
        return eligibility
    }

    /**
     * Surveys can be activated by events or actions. This method checks if the survey has events and actions,
     * and if so, it checks if the survey has been activated.
     * @param survey
     */
    private _hasActionOrEventTriggeredSurvey(survey: Survey): boolean {
        if (!doesSurveyActivateByEvent(survey) && !doesSurveyActivateByAction(survey)) {
            // If survey doesn't depend on events/actions, it's considered "triggered" by default
            return true
        }
        const surveysActivatedByEventsOrActions: string[] | undefined =
            this._posthog.surveys?._surveyEventReceiver?.getSurveys()
        return !!surveysActivatedByEventsOrActions?.includes(survey.id)
    }

    private _checkFlags(survey: Survey): boolean {
        if (!survey.feature_flag_keys?.length) {
            return true
        }

        return survey.feature_flag_keys.every(({ key, value }) => {
            if (!key || !value) {
                return true
            }
            return this._isSurveyFeatureFlagEnabled(value)
        })
    }

    /**
     * The full predicate for "should this survey display right now": eligibility (running,
     * type, linked/targeting/internal flags, wait period, already-seen) plus the URL/device/
     * selector conditions, the event/action trigger, and any feature-flag dependencies.
     *
     * Shared by the display loop and re-checked when a popover's delay timer fires, so a
     * survey that became ineligible *during* the delay (e.g. an identify() reloaded flags and
     * the internal targeting flag is now false) is not shown. Note this is purely an AND gate:
     * adding it can only ever suppress a display, never cause an extra one.
     *
     * PostHog's capture state is not part of this: it also backs the public
     * `getActiveMatchingSurveys` discovery result, so the paths where the SDK renders the survey
     * itself apply that gate separately — see `checkSurveyDisplayEligibility`.
     */
    private _shouldDisplaySurvey(survey: Survey): boolean {
        return (
            this.checkSurveyEligibility(survey).eligible &&
            this._isSurveyConditionMatched(survey) &&
            this._hasActionOrEventTriggeredSurvey(survey) &&
            this._checkFlags(survey)
        )
    }

    public getActiveMatchingSurveys = (callback: SurveyCallback, forceReload = false): void => {
        this._posthog?.surveys?.getSurveys((surveys) => {
            const targetingMatchedSurveys = surveys.filter((survey) => this._shouldDisplaySurvey(survey))
            callback(targetingMatchedSurveys)
        }, forceReload)
    }

    public callSurveysAndEvaluateDisplayLogic = (forceReload: boolean = false): void => {
        this.getActiveMatchingSurveys((surveys) => {
            // Discovery above stays capture-independent for custom integrations; a survey the SDK
            // shows itself must be able to record the response, so the gate lives here instead —
            // see `checkSurveyDisplayEligibility`.
            const canCaptureResponse = isCapturingEnabled(this._posthog)
            const inAppSurveysWithDisplayLogic = surveys.filter(
                (survey) =>
                    canCaptureResponse && (survey.type === SurveyType.Popover || survey.type === SurveyType.Widget)
            )

            // Cancel any pending (delayed, not-yet-shown) survey whose eligibility changed since
            // it was queued — e.g. an identify() during the delay flipped its targeting flag.
            // This frees the popover focus promptly instead of waiting for a now-stale timer to
            // fire. Safe for already-shown surveys: their timer is gone, so cancelSurvey no-ops.
            const matchingIds = new Set(inAppSurveysWithDisplayLogic.map((survey) => survey.id))
            for (const pendingSurveyId of Array.from(this._surveyTimeouts.keys())) {
                if (!matchingIds.has(pendingSurveyId)) {
                    this.cancelSurvey(pendingSurveyId)
                }
            }

            // Create a queue of surveys sorted by their appearance delay.  We will evaluate the display logic
            // for each survey in the queue in order, and only display one survey at a time.
            const inAppSurveysQueue = this._sortSurveysByAppearanceDelay(inAppSurveysWithDisplayLogic)

            // Keep track of surveys processed this cycle to remove listeners for inactive ones
            const activeSelectorSurveys = new Set<string>()
            const activeTabWidgetSurveys = new Set<string>()

            inAppSurveysQueue.forEach((survey) => {
                // Widget Type Logic
                if (survey.type === SurveyType.Widget) {
                    if (survey.appearance?.widgetType === SurveyWidgetType.Tab) {
                        activeTabWidgetSurveys.add(survey.id)
                        this._handleWidget(survey)
                        return
                    }

                    // For selector widget types, we need to manage the listener attachment/detachment dynamically
                    if (
                        survey.appearance?.widgetType === SurveyWidgetType.Selector &&
                        survey.appearance?.widgetSelector
                    ) {
                        activeSelectorSurveys.add(survey.id)
                        this._manageWidgetSelectorListener(survey, survey.appearance?.widgetSelector)
                    }
                }

                // Popover Type Logic (only one shown at a time)
                if (isNull(this._surveyInFocus) && survey.type === SurveyType.Popover) {
                    this.handlePopoverSurvey(survey, undefined, { resumeDelayFromActivation: true })
                }
            })

            // Clean up listeners for surveys that are no longer active or matched
            this._widgetSelectorListeners.forEach(({ survey }) => {
                if (!activeSelectorSurveys.has(survey.id)) {
                    this._removeWidgetSelectorListener(survey)
                }
            })

            // Same cleanup for a tab widget, which has no listener entry to key off.
            this._renderedTabWidgets.forEach((tabSurvey, surveyId) => {
                if (!activeTabWidgetSurveys.has(surveyId)) {
                    this._removeTabWidget(tabSurvey)
                }
            })
        }, forceReload)
    }

    private _addSurveyToFocus = (survey: Pick<Survey, 'id'>): void => {
        if (!isNull(this._surveyInFocus)) {
            logger.error(`Survey ${this._surveyInFocus} already in focus. Cannot add survey ${survey.id}.`)
        }
        this._surveyInFocus = survey.id
    }

    private _removeSurveyFromDom(survey: Pick<Survey, 'id' | 'type' | 'appearance'>): void {
        try {
            const shadowContainer = document.querySelector(getSurveyContainerClass(survey, true))
            if (shadowContainer?.shadowRoot) {
                render(null, shadowContainer.shadowRoot)
                this._renderedTargets.delete(shadowContainer.shadowRoot)
            }
            shadowContainer?.remove()
        } catch (error) {
            logger.warn(`Failed to remove survey ${survey.id} from DOM:`, error)
        }
    }

    private _removeSurveyFromFocus = (survey: SurveyWithTypeAndAppearance): void => {
        if (this._surveyInFocus !== survey.id) {
            logger.error(`Survey ${survey.id} is not in focus. Cannot remove survey ${survey.id}.`)
        }
        this._clearSurveyTimeout(survey.id)
        this._surveyInFocus = null
        this._currentLanguage = null
        this._surveyIsRendered = false
        this._surveyPopupProps = null
        this._displayOptions = undefined
        this._removeSurveyFromDom(survey)
    }

    // Expose internal state and methods for testing
    public getTestAPI() {
        return {
            addSurveyToFocus: this._addSurveyToFocus,
            removeSurveyFromFocus: this._removeSurveyFromFocus,
            surveyInFocus: this._surveyInFocus,
            surveyTimeouts: this._surveyTimeouts,
            handleWidget: this._handleWidget,
            handlePopoverSurvey: this.handlePopoverSurvey,
            manageWidgetSelectorListener: this._manageWidgetSelectorListener,
            sortSurveysByAppearanceDelay: this._sortSurveysByAppearanceDelay,
            checkFlags: this._checkFlags.bind(this),
            isSurveyFeatureFlagEnabled: this._isSurveyFeatureFlagEnabled.bind(this),
            onLanguageChange: this._onLanguageChange.bind(this),
            currentLanguage: this._currentLanguage,
            surveyIsRendered: this._surveyIsRendered,
        }
    }
}

const DEFAULT_PREVIEW_POSITION_STYLES: JSX.CSSProperties = {
    position: 'relative',
    left: 'unset',
    right: 'unset',
    top: 'unset',
    bottom: 'unset',
    transform: 'unset',
}

export const renderSurveysPreview = ({
    survey,
    parentElement,
    previewPageIndex,
    forceDisableHtml,
    onPreviewSubmit,
    onPreviewBack,
    positionStyles = DEFAULT_PREVIEW_POSITION_STYLES,
}: {
    survey: Survey
    parentElement: HTMLElement
    previewPageIndex: number
    forceDisableHtml?: boolean
    onPreviewSubmit?: (res: string | string[] | number | null) => void
    onPreviewBack?: () => void
    posthog?: PostHog
    positionStyles?: JSX.CSSProperties
}) => {
    const currentStyle = parentElement.querySelector('style[data-ph-survey-style]')
    if (currentStyle) {
        currentStyle.remove()
    }
    const stylesheet = getSurveyStylesheet()
    if (stylesheet) {
        parentElement.appendChild(stylesheet)
        addSurveyCSSVariablesToElement(parentElement, survey.type, survey.appearance)
    }
    render(
        <SurveyPopup
            survey={survey}
            forceDisableHtml={forceDisableHtml}
            style={positionStyles}
            onPreviewSubmit={onPreviewSubmit}
            onPreviewBack={onPreviewBack}
            previewPageIndex={previewPageIndex}
            removeSurveyFromFocus={() => {}}
        />,
        parentElement
    )
}

export const renderFeedbackWidgetPreview = ({
    survey,
    root,
    forceDisableHtml,
}: {
    survey: Survey
    root: HTMLElement
    forceDisableHtml?: boolean
}) => {
    const stylesheet = getSurveyStylesheet()
    if (stylesheet) {
        root.appendChild(stylesheet)
        addSurveyCSSVariablesToElement(root, survey.type, survey.appearance)
    }

    render(<FeedbackWidget forceDisableHtml={forceDisableHtml} survey={survey} readOnly={true} />, root)
}

// This is the main exported function
export function generateSurveys(posthog: PostHog, isSurveysEnabled: boolean | undefined) {
    // NOTE: Important to ensure we never try and run surveys without a window environment
    if (!document || !window) {
        return
    }

    const surveyManager = new SurveyManager(posthog)
    if (posthog.config.disable_surveys_automatic_display) {
        logger.info('Surveys automatic display is disabled. Skipping call surveys and evaluate display logic.')
        return surveyManager
    }

    // NOTE: The `generateSurveys` function used to accept just a single parameter, without any `isSurveysEnabled` parameter.
    // To keep compatibility with old clients, we'll consider `undefined` the same as `true`
    if (isSurveysEnabled === false) {
        logger.info('There are no surveys to load or Surveys is disabled in the project settings.')
        return surveyManager
    }

    surveyManager.callSurveysAndEvaluateDisplayLogic(true)

    let intervalId: number | undefined

    const startInterval = () => {
        if (!isUndefined(intervalId)) {
            return
        }
        intervalId = setInterval(() => {
            surveyManager.callSurveysAndEvaluateDisplayLogic(false)
        }, 1000) as unknown as number
    }

    const stopInterval = () => {
        if (!isUndefined(intervalId)) {
            clearInterval(intervalId)
            intervalId = undefined
        }
    }

    startInterval()

    const onVisibilityChange = () => {
        if (document.hidden) {
            stopInterval()
        } else {
            surveyManager.callSurveysAndEvaluateDisplayLogic(false)
            startInterval()
        }
    }
    addEventListener(document, 'visibilitychange', onVisibilityChange)
    surveyManager.setAutomaticDisplayDispose(() => {
        stopInterval()
        document.removeEventListener('visibilitychange', onVisibilityChange)
    })

    return surveyManager
}

type UseHideSurveyOnURLChangeProps = {
    survey: Pick<Survey, 'id' | 'conditions' | 'type' | 'appearance'>
    removeSurveyFromFocus?: (survey: SurveyWithTypeAndAppearance) => void
    setSurveyVisible: (visible: boolean) => void
    isPreviewMode?: boolean
    posthog?: PostHog
}

/**
 * This hook handles URL-based survey visibility after the initial mount.
 * The initial URL check is handled by the `getActiveMatchingSurveys` method in  the `PostHogSurveys` class,
 * which ensures the URL matches before displaying a survey for the first time.
 * That is the method that is called every second to see if there's a matching survey.
 *
 * This separation of concerns means:
 * 1. Initial URL matching is done by `getActiveMatchingSurveys` before displaying the survey
 * 2. Subsequent URL changes are handled here to hide the survey as the user navigates
 */
export function useHideSurveyOnURLChange({
    survey,
    removeSurveyFromFocus = () => {},
    setSurveyVisible,
    isPreviewMode = false,
    posthog,
}: UseHideSurveyOnURLChangeProps) {
    useEffect(() => {
        if (isPreviewMode || !survey.conditions?.url) {
            return
        }

        const checkUrlMatch = () => {
            const isSurveyTypeWidget = survey.type === SurveyType.Widget
            const doesSurveyMatchUrlCondition = doesSurveyUrlMatch(survey, posthog)
            const isSurveyWidgetTypeTab = survey.appearance?.widgetType === SurveyWidgetType.Tab && isSurveyTypeWidget

            if (doesSurveyMatchUrlCondition) {
                if (isSurveyWidgetTypeTab) {
                    logger.info(`Showing survey ${survey.id} because it is a feedback button tab and URL matches`)
                    setSurveyVisible(true)
                }
                return
            }

            logger.info(`Hiding survey ${survey.id} because URL does not match`)
            setSurveyVisible(false)
            return removeSurveyFromFocus(survey)
        }

        // Listen for browser back/forward browser history changes
        addEventListener(window, 'popstate', checkUrlMatch)
        // Listen for hash changes, for SPA frameworks that use hash-based routing
        // The hashchange event is fired when the fragment identifier of the URL has changed (the part of the URL beginning with and following the # symbol).
        addEventListener(window, 'hashchange', checkUrlMatch)

        // Listen for SPA navigation
        const originalPushState = window.history.pushState
        const originalReplaceState = window.history.replaceState

        window.history.pushState = function (...args) {
            originalPushState.apply(this, args)
            checkUrlMatch()
        }

        window.history.replaceState = function (...args) {
            originalReplaceState.apply(this, args)
            checkUrlMatch()
        }

        return () => {
            window.removeEventListener('popstate', checkUrlMatch)
            window.removeEventListener('hashchange', checkUrlMatch)
            window.history.pushState = originalPushState
            window.history.replaceState = originalReplaceState
        }
    }, [isPreviewMode, survey, removeSurveyFromFocus, setSurveyVisible, posthog])
}

// Duration of the survey close fade-out, in milliseconds. Kept short so the popup
// disappears promptly; also the window the fallback settle timer waits on.
const CLOSE_ANIMATION_DURATION_MS = 200

export function usePopupVisibility(
    survey: Survey,
    posthog: PostHog | undefined,
    millisecondDelay: number,
    isPreviewMode: boolean,
    removeSurveyFromFocus: (survey: SurveyWithTypeAndAppearance) => void,
    isPopup: boolean,
    surveyContainerRef?: RefObject<HTMLDivElement>,
    skipShownEvent?: boolean,
    surveyLanguage?: string | null
) {
    const [isPopupVisible, setIsPopupVisible] = useState(
        isPreviewMode || millisecondDelay === 0 || survey.type === SurveyType.ExternalSurvey
    )
    const [isSurveySent, setIsSurveySent] = useState(false)

    // Tracks whether a close is already animating so a second close (e.g. Enter +
    // button click, or a dismiss fired while the thank-you screen is animating out)
    // doesn't start a second animation or tear the popup down twice.
    const isClosingRef = useRef(false)

    const hidePopupWithAnimation = () => {
        const removeDOMAndHidePopup = () => {
            if (isPopup) {
                removeSurveyFromFocus(survey)
            }
            setIsPopupVisible(false)
        }

        // A close is already animating. Don't start a second one — the in-flight
        // close settles the popup when it finishes.
        if (isClosingRef.current) {
            return
        }

        // No element to animate (jsdom, or the ref never attached): tear down now.
        // Do this before raising isClosingRef so the guard is only ever set for a real
        // in-flight animation — this early return has no timer to clear it, so setting
        // the flag here would leave it stuck and block every later close.
        const container = surveyContainerRef?.current
        if (!container) {
            removeDOMAndHidePopup()
            return
        }

        // Committing to the fade now — raise the guard so a second close can't start
        // another animation; the settle timer below clears it.
        isClosingRef.current = true

        // Fade the popup out with a plain CSS opacity transition scoped to the
        // survey's own container, which lives in an isolated shadow root. We
        // deliberately do NOT use document.startViewTransition: that API snapshots
        // the ENTIRE page viewport, and on a heavy host page (e.g. a large dashboard)
        // capturing that snapshot can exhaust renderer memory and crash the tab (grey
        // "Aw, Snap"). A scoped opacity transition costs nothing on the rest of the page.
        container.style.transition = `opacity ${CLOSE_ANIMATION_DURATION_MS}ms ease-out`
        container.style.opacity = '0'

        // Unmount once the fade has had time to run. This uses a timer rather than a
        // `transitionend` listener because transitionend never fires for a cancelled or
        // zero-duration transition (backgrounded tab, reduced motion), so a timer would
        // have to back it up regardless — and settling a few ms later than strictly
        // necessary is imperceptible for an element that is already fully transparent.
        setTimeout(() => {
            isClosingRef.current = false
            removeDOMAndHidePopup()
        }, CLOSE_ANIMATION_DURATION_MS + 50)
    }

    const handleSurveyClosed = (event: CustomEvent) => {
        if (event.detail.surveyId !== survey.id) {
            return
        }
        hidePopupWithAnimation()
    }

    useEffect(() => {
        if (!posthog) {
            logger.error('usePopupVisibility hook called without a PostHog instance.')
            return
        }
        if (isPreviewMode) {
            return
        }

        let autoDisappearTimeout: ReturnType<typeof setTimeout> | undefined
        const handleSurveySent = (event: CustomEvent) => {
            if (event.detail.surveyId !== survey.id) {
                return
            }
            if (!survey.appearance?.displayThankYouMessage) {
                return hidePopupWithAnimation()
            }
            setIsSurveySent(true)
            if (survey.appearance?.autoDisappear) {
                if (autoDisappearTimeout) {
                    clearTimeout(autoDisappearTimeout)
                }
                autoDisappearTimeout = setTimeout(hidePopupWithAnimation, 5000)
            }
        }

        const showSurvey = () => {
            // check if the url is still matching, necessary for delayed surveys, as the URL may have changed
            if (!doesSurveyUrlMatch(survey, posthog)) {
                return
            }
            setIsPopupVisible(true)
            try {
                localStorage.setItem('lastSeenSurveyDate', new Date().toISOString())
            } catch {
                // localStorage is not always available (e.g. in cross-origin iframes).
            }
            window.dispatchEvent(new Event('PHSurveyShown'))
            if (!skipShownEvent) {
                posthog.capture(SurveyEventName.SHOWN, {
                    [SurveyEventProperties.SURVEY_NAME]: survey.name,
                    [SurveyEventProperties.SURVEY_ID]: survey.id,
                    [SurveyEventProperties.SURVEY_ITERATION]: survey.current_iteration,
                    [SurveyEventProperties.SURVEY_ITERATION_START_DATE]: survey.current_iteration_start_date,
                    ...(surveyLanguage && { [SurveyEventProperties.SURVEY_LANGUAGE]: surveyLanguage }),
                    sessionRecordingUrl: posthog.get_session_replay_url?.(),
                })
            }
        }

        addEventListener(window, 'PHSurveyClosed', handleSurveyClosed as EventListener)
        addEventListener(window, 'PHSurveySent', handleSurveySent as EventListener)

        // The delay path is only used for direct usage of SurveyPopup, not surveys managed by SurveyManager.
        const showTimeout = millisecondDelay > 0 ? setTimeout(showSurvey, millisecondDelay) : undefined
        if (isUndefined(showTimeout)) {
            showSurvey()
        }
        return () => {
            if (!isUndefined(showTimeout)) {
                clearTimeout(showTimeout)
            }
            if (!isUndefined(autoDisappearTimeout)) {
                clearTimeout(autoDisappearTimeout)
            }
            window.removeEventListener('PHSurveyClosed', handleSurveyClosed as EventListener)
            window.removeEventListener('PHSurveySent', handleSurveySent as EventListener)
        }
    }, [])

    useHideSurveyOnURLChange({
        survey,
        removeSurveyFromFocus,
        setSurveyVisible: setIsPopupVisible,
        isPreviewMode,
        posthog,
    })

    return { isPopupVisible, isSurveySent, setIsPopupVisible, hidePopupWithAnimation }
}

interface SurveyPopupProps {
    survey: Survey
    forceDisableHtml?: boolean
    posthog?: PostHog
    style?: JSX.CSSProperties
    previewPageIndex?: number | undefined
    removeSurveyFromFocus?: (survey: SurveyWithTypeAndAppearance) => void
    isPopup?: boolean
    onPreviewSubmit?: (res: string | string[] | number | null) => void
    onPreviewBack?: () => void
    onPopupSurveyDismissed?: () => void
    onCloseConfirmationMessage?: () => void
    /** Additional properties to include in all survey events */
    properties?: Properties
    /** if true, survey popup will only render if there is a thank-you message */
    isSurveyCompleted?: boolean
    /** When true, `survey shown` events will not be emitted automatically */
    skipShownEvent?: boolean
    /** The language that was applied to the survey. */
    surveyLanguage?: string | null
}

function getTabPositionStyles(position: SurveyTabPosition = SurveyTabPosition.Right): JSX.CSSProperties {
    switch (position) {
        case SurveyTabPosition.Top:
            return { top: '0', left: '50%', transform: 'translateX(-50%)' }
        case SurveyTabPosition.Left:
            return { top: '50%', left: '0', transform: 'rotate(90deg) translateY(-100%)', transformOrigin: 'left top' }
        case SurveyTabPosition.Bottom: // bottom center
            return { bottom: '0', left: '50%', transform: 'translateX(-50%)' }
        default:
        case SurveyTabPosition.Right:
            // not perfectly centered vertically, to avoid a "breaking" change
            return {
                top: '50%',
                right: '0',
                transform: 'rotate(-90deg) translateY(-100%)',
                transformOrigin: 'right top',
            }
    }
}

export function SurveyPopup({
    survey,
    forceDisableHtml,
    posthog,
    style = {},
    previewPageIndex,
    removeSurveyFromFocus = () => {},
    isPopup = true,
    onPreviewSubmit = () => {},
    onPreviewBack = () => {},
    onPopupSurveyDismissed = () => {},
    onCloseConfirmationMessage = () => {},
    properties,
    isSurveyCompleted,
    skipShownEvent,
    surveyLanguage,
}: SurveyPopupProps) {
    const surveyContainerRef = useRef<HTMLDivElement>(null)
    const isPreviewMode = Number.isInteger(previewPageIndex)
    // NB: The client-side code passes the millisecondDelay in seconds, but setTimeout expects milliseconds, so we multiply by 1000
    const surveyPopupDelayMilliseconds = survey.appearance?.surveyPopupDelaySeconds
        ? survey.appearance.surveyPopupDelaySeconds * 1000
        : 0
    const { isPopupVisible, isSurveySent, hidePopupWithAnimation } = usePopupVisibility(
        survey,
        posthog,
        surveyPopupDelayMilliseconds,
        isPreviewMode,
        removeSurveyFromFocus,
        isPopup,
        surveyContainerRef,
        skipShownEvent,
        surveyLanguage
    )

    /**
     * show confirmation if:
     * 1) isSurveySent is true (completed via normal flow)
     * 2) we're on the preview page for it
     * 3) the target start question (from prefill) is >= the length of the survey
     */
    const shouldShowConfirmation =
        isSurveySent || previewPageIndex === survey.questions.length || isSurveyCompleted === true

    const [introScreenDismissed, setIntroScreenDismissed] = useState(false)
    const hasInProgressState = useMemo(() => !!getInProgressSurveyState(survey), [survey])
    /**
     * The intro screen is a leading page, the mirror of the trailing confirmation message. It is
     * skipped whenever the survey already has answers in progress (resumed session or URL
     * prefill), and dismissing it only flips local state — no event, no response, no effect on
     * completion or partial-response accounting. The confirmation check above always wins so a
     * completed survey never shows the intro. Unlike the confirmation message the intro has no
     * default header, so a survey with no intro copy at all skips straight to question 1 rather
     * than drawing an empty box with a button.
     */
    const hasIntroContent = !!(survey.appearance?.introScreenHeader || survey.appearance?.introScreenDescription)
    const shouldShowIntroScreen = isPreviewMode
        ? previewPageIndex === INTRO_SCREEN_PREVIEW_INDEX
        : !!survey.appearance?.displayIntroScreen && hasIntroContent && !introScreenDismissed && !hasInProgressState

    const surveyContextValue = useMemo(() => {
        const getInProgressSurvey = getInProgressSurveyState(survey)
        const surveySubmissionId = getInProgressSurvey?.surveySubmissionId || uuidv7()
        return {
            isPreviewMode,
            previewPageIndex: previewPageIndex,
            onPopupSurveyDismissed: () => {
                if (surveyLanguage) {
                    dismissedSurveyEvent(survey, posthog, isPreviewMode, surveyLanguage)
                } else {
                    dismissedSurveyEvent(survey, posthog, isPreviewMode)
                }
                onPopupSurveyDismissed()
            },
            isPopup: isPopup || false,
            surveySubmissionId,
            onPreviewSubmit,
            onPreviewBack,
            posthog,
            properties,
            surveyLanguage,
        }
    }, [
        isPreviewMode,
        previewPageIndex,
        isPopup,
        posthog,
        survey,
        onPopupSurveyDismissed,
        onPreviewSubmit,
        onPreviewBack,
        properties,
        surveyLanguage,
    ])

    if (!isPopupVisible) {
        return null
    }

    return (
        <SurveyContext.Provider value={surveyContextValue}>
            <div
                className="ph-survey"
                style={{
                    ...getPopoverPosition(survey.type, survey.appearance?.position, survey.appearance?.widgetType),
                    ...style,
                }}
                ref={surveyContainerRef}
            >
                {shouldShowConfirmation ? (
                    <ConfirmationMessage
                        header={survey.appearance?.thankYouMessageHeader || 'Thank you!'}
                        description={survey.appearance?.thankYouMessageDescription || ''}
                        forceDisableHtml={!!forceDisableHtml}
                        contentType={survey.appearance?.thankYouMessageDescriptionContentType}
                        appearance={survey.appearance || defaultSurveyAppearance}
                        onClose={() => {
                            hidePopupWithAnimation()
                            onCloseConfirmationMessage()
                        }}
                    />
                ) : shouldShowIntroScreen ? (
                    <IntroScreen
                        header={survey.appearance?.introScreenHeader || ''}
                        description={survey.appearance?.introScreenDescription || ''}
                        forceDisableHtml={!!forceDisableHtml}
                        contentType={survey.appearance?.introScreenDescriptionContentType}
                        appearance={survey.appearance || defaultSurveyAppearance}
                        onStart={() => setIntroScreenDismissed(true)}
                    />
                ) : (
                    <Questions survey={survey} forceDisableHtml={!!forceDisableHtml} posthog={posthog} />
                )}
            </div>
        </SurveyContext.Provider>
    )
}

export function Questions({
    survey,
    forceDisableHtml,
    posthog,
}: {
    survey: Survey
    forceDisableHtml: boolean
    posthog?: PostHog
}) {
    // Read the persisted in-progress state once and sanitize it. A stale persisted index (e.g.
    // left over from a prior completion) can point past the end of the questions array, which
    // makes the question renderer bail and leaves the survey container empty. When that happens
    // the whole record is stale, so we discard it and start fresh rather than clamping the index
    // while keeping the equally-stale responses and visited indices around.
    const initialInProgressState = useMemo(() => {
        const state = getInProgressSurveyState(survey)
        if (!state) {
            return null
        }
        // Only an index that is actually present and out of range signals a stale record (e.g.
        // left over from a prior completion) whose responses should be dropped. A missing, NaN or
        // otherwise non-numeric index just predates the persisted-index feature — keep the
        // responses and start from question 0 (the reader below defaults to it).
        const hasIndex = isNumber(state.lastQuestionIndex)
        const isIndexInRange =
            hasIndex && state.lastQuestionIndex >= 0 && state.lastQuestionIndex < survey.questions.length
        if (hasIndex && !isIndexInRange) {
            clearInProgressSurveyState(survey)
            return null
        }
        return state
        // Only recompute when the survey identity changes; we intentionally read localStorage once.
    }, [survey])

    // Initialize responses from localStorage or empty object
    const [questionsResponses, setQuestionsResponses] = useState(() => {
        if (initialInProgressState?.responses) {
            logger.info('Survey is already in progress, filling in initial responses')
        }
        return initialInProgressState?.responses || {}
    })
    const [submissionBlocked, setSubmissionBlocked] = useState(false)
    const {
        previewPageIndex,
        onPopupSurveyDismissed,
        isPopup,
        onPreviewSubmit,
        onPreviewBack,
        surveySubmissionId,
        isPreviewMode,
        properties,
        surveyLanguage,
    } = useContext(SurveyContext)
    const [currentQuestionIndex, setCurrentQuestionIndex] = useState(() => {
        // Fall back to the first question for a missing, NaN or out-of-range persisted index so a
        // resumed survey always renders a real question rather than an empty container.
        const savedIndex = initialInProgressState?.lastQuestionIndex
        const validSavedIndex =
            isNumber(savedIndex) && savedIndex >= 0 && savedIndex < survey.questions.length ? savedIndex : 0
        // The intro screen preview sentinel (INTRO_SCREEN_PREVIEW_INDEX) is handled at the
        // SurveyPopup level and must never become a question index.
        return isNumber(previewPageIndex) && previewPageIndex >= 0 ? previewPageIndex : validSavedIndex
    })
    const [visitedIndices, setVisitedIndices] = useState<number[]>(() => {
        // Drop any out-of-range visited indices so the Back button can never navigate to a
        // non-existent question (which would re-empty the container).
        return (initialInProgressState?.visitedIndices ?? []).filter(
            (index) => index >= 0 && index < survey.questions.length
        )
    })
    const [questionSnapshots, setQuestionSnapshots] = useState<Record<string, string>>(() => {
        const inProgressSurveyData = getInProgressSurveyState(survey)
        return inProgressSurveyData?.questionSnapshots ?? {}
    })
    // A shuffled survey's display order (and any random shuffle) must stay fixed across a
    // language re-translation. Re-translating gives `survey` a new object identity on every
    // render, so keying this off `survey` directly would recompute — and for a shuffled survey,
    // reshuffle — the order on every language change. Compute the order once per survey.id from
    // question ids, then map those ids onto whatever the current (possibly re-translated)
    // question objects are, so text updates but order holds.
    const questionOrderIds = useMemo(
        () => getQuestionOrder(getDisplayOrderQuestions(survey, initialInProgressState)),
        [survey.id, initialInProgressState]
    )
    const surveyQuestions = useMemo(() => {
        // Some questions lack an id (older data), or two questions share one (seen in a couple
        // of playwright fixtures) — either way a Map keyed by id can't disambiguate positions,
        // so fall back to recomputing fresh each time rather than mapping id -> question.
        const hasUsableIds = !!questionOrderIds && new Set(questionOrderIds).size === questionOrderIds.length
        if (!hasUsableIds) {
            return getDisplayOrderQuestions(survey, initialInProgressState)
        }
        const byId = new Map(survey.questions.map((question) => [question.id, question]))
        const mapped = questionOrderIds
            .map((id) => byId.get(id))
            .filter((question): question is SurveyQuestion => !!question)
        return mapped.length === questionOrderIds.length ? mapped : survey.questions
    }, [questionOrderIds, survey.questions, survey, initialInProgressState])

    // Sync preview state. Negative sentinels (the intro screen page) are rendered by SurveyPopup
    // instead of Questions, so they must never reach currentQuestionIndex.
    useEffect(() => {
        if (isPreviewMode && !isUndefined(previewPageIndex) && previewPageIndex >= 0) {
            setCurrentQuestionIndex(previewPageIndex)
        }
    }, [previewPageIndex, isPreviewMode])

    const onNextButtonClick = ({
        res,
        displayQuestionIndex,
        questionId,
    }: {
        res: string | string[] | number | null
        displayQuestionIndex: number
        questionId?: string
    }) => {
        if (!posthog) {
            logger.error('onNextButtonClick called without a PostHog instance.')
            return
        }

        if (!isCapturingEnabled(posthog)) {
            setSubmissionBlocked(true)
            return
        }
        setSubmissionBlocked(false)

        if (!questionId) {
            logger.error('onNextButtonClick called without a questionId.')
            return
        }

        const { responses: newResponses, questionSnapshots: newSnapshots } = recordSurveyAnswer(
            { responses: questionsResponses, questionSnapshots },
            questionId,
            res,
            surveyQuestions[displayQuestionIndex]
        )
        setQuestionsResponses(newResponses)
        setQuestionSnapshots(newSnapshots)

        const nextStep = getNextSurveyStep(survey, displayQuestionIndex, res)
        const isSurveyCompleted = nextStep === SurveyQuestionBranchingType.End
        const newVisitedIndices = [...visitedIndices, displayQuestionIndex]

        if (!isSurveyCompleted) {
            setVisitedIndices(newVisitedIndices)
            setCurrentQuestionIndex(nextStep)
            setInProgressSurveyState(survey, {
                surveySubmissionId: surveySubmissionId,
                responses: newResponses,
                lastQuestionIndex: nextStep,
                questionOrder: getQuestionOrder(surveyQuestions),
                visitedIndices: newVisitedIndices,
                surveyLanguage,
                questionSnapshots: newSnapshots,
            })
        }

        // If partial responses are enabled, send the survey sent event with with the responses,
        // otherwise only send the event when the survey is completed
        if (survey.enable_partial_responses || isSurveyCompleted) {
            // Only emit responses for questions actually on the path the user took. This prunes
            // ghost answers from branches the user abandoned by backing up and choosing differently.
            const visitedResponseKeys = new Set(
                newVisitedIndices
                    .map((i) => surveyQuestions[i]?.id)
                    .filter((id): id is string => !!id)
                    .map((id) => getSurveyResponseKey(id))
            )
            const responsesOnPath = Object.fromEntries(
                Object.entries(newResponses).filter(([key]) => visitedResponseKeys.has(key))
            )
            sendSurveyEvent({
                responses: responsesOnPath,
                survey,
                surveySubmissionId,
                isSurveyCompleted,
                posthog,
                properties,
                surveyLanguage,
                questionSnapshots: newSnapshots,
            })
        }
    }

    const onBackButtonClick = () => {
        // In preview mode the parent owns navigation (via previewPageIndex), so delegate to it.
        if (isPreviewMode) {
            onPreviewBack()
            return
        }
        if (visitedIndices.length === 0) {
            return
        }
        const previousIndex = visitedIndices[visitedIndices.length - 1]
        const newVisitedIndices = visitedIndices.slice(0, -1)
        setVisitedIndices(newVisitedIndices)
        setCurrentQuestionIndex(previousIndex)
        setInProgressSurveyState(survey, {
            surveySubmissionId,
            responses: questionsResponses,
            lastQuestionIndex: previousIndex,
            questionOrder: getQuestionOrder(surveyQuestions),
            visitedIndices: newVisitedIndices,
            surveyLanguage,
            questionSnapshots,
        })
    }

    const canGoBack =
        !!survey.appearance?.allowGoBack && (isPreviewMode ? (previewPageIndex ?? 0) > 0 : visitedIndices.length > 0)

    const currentQuestion = surveyQuestions.at(currentQuestionIndex)

    if (!currentQuestion) {
        return null
    }

    const renderCancelButton = isPopup && survey.appearance?.hideCancelButton !== true

    return (
        <form className="survey-form" name="surveyForm">
            {renderCancelButton && (
                <Cancel
                    onClick={() => {
                        onPopupSurveyDismissed()
                    }}
                />
            )}
            <div className="survey-box" data-question-index={currentQuestionIndex}>
                {submissionBlocked && <p role="alert">Your response could not be sent. Please try again later.</p>}
                {getQuestionComponent({
                    question: currentQuestion,
                    forceDisableHtml,
                    displayQuestionIndex: currentQuestionIndex,
                    appearance: survey.appearance || defaultSurveyAppearance,
                    onSubmit: (res) =>
                        onNextButtonClick({
                            res,
                            displayQuestionIndex: currentQuestionIndex,
                            questionId: currentQuestion.id,
                        }),
                    onPreviewSubmit,
                    initialValue: currentQuestion.id
                        ? questionsResponses[getSurveyResponseKey(currentQuestion.id)]
                        : undefined,
                    canGoBack,
                    onBack: onBackButtonClick,
                })}
            </div>
        </form>
    )
}

export function FeedbackWidget({
    survey,
    forceDisableHtml,
    posthog,
    readOnly,
    surveyLanguage,
}: {
    survey: Survey
    forceDisableHtml?: boolean
    posthog?: PostHog
    readOnly?: boolean
    surveyLanguage?: string | null
}): JSX.Element | null {
    const [isFeedbackButtonVisible, setIsFeedbackButtonVisible] = useState(true)
    const [showSurvey, setShowSurvey] = useState(false)
    const [styleOverrides, setStyleOverrides] = useState<JSX.CSSProperties>({})
    const resetTimeout = useRef<ReturnType<typeof setTimeout> | undefined>(undefined)

    const toggleSurvey = () => {
        if (!showSurvey && posthog && !readOnly && !isCapturingEnabled(posthog)) {
            return
        }
        setShowSurvey(!showSurvey)
    }

    useEffect(() => {
        if (!posthog) {
            logger.error('FeedbackWidget called without a PostHog instance.')
            return
        }
        if (readOnly) {
            return
        }

        if (survey.appearance?.widgetType === 'tab') {
            setStyleOverrides({
                top: '50%',
                bottom: 'auto',
            })
        }
        const handleShowSurvey = (event: Event) => {
            const customEvent = event as CustomEvent
            // Check if the event is for this specific survey instance
            if (customEvent.detail?.surveyId === survey.id) {
                logger.info(`Received show event for feedback button survey ${survey.id}`)
                setStyleOverrides(customEvent.detail.position || {})
                toggleSurvey()
            }
        }

        addEventListener(window, DISPATCH_FEEDBACK_WIDGET_EVENT, handleShowSurvey)

        return () => {
            if (!isUndefined(resetTimeout.current)) {
                clearTimeout(resetTimeout.current)
                resetTimeout.current = undefined
            }
            window.removeEventListener(DISPATCH_FEEDBACK_WIDGET_EVENT, handleShowSurvey)
        }
    }, [
        posthog,
        readOnly,
        survey.id,
        survey.appearance?.widgetType,
        survey.appearance?.widgetSelector,
        survey.appearance?.borderColor,
    ])

    useHideSurveyOnURLChange({
        survey,
        setSurveyVisible: setIsFeedbackButtonVisible,
        posthog,
    })

    if (!isFeedbackButtonVisible) {
        return null
    }

    const resetShowSurvey = () => {
        // hide the feedback button after answering or closing the survey if it's not always show
        if (survey.schedule !== SurveySchedule.Always) {
            setIsFeedbackButtonVisible(false)
        }
        // important so our view transition has time to run
        if (!isUndefined(resetTimeout.current)) {
            clearTimeout(resetTimeout.current)
        }
        resetTimeout.current = setTimeout(() => {
            resetTimeout.current = undefined
            setShowSurvey(false)
        }, 200)
    }

    return (
        <Fragment>
            {survey.appearance?.widgetType === 'tab' && (
                <button
                    className={`ph-survey-widget-tab ${survey.appearance?.tabPosition === SurveyTabPosition.Top ? 'widget-tab-top' : ''}`}
                    onClick={toggleSurvey}
                    disabled={readOnly}
                    style={getTabPositionStyles(survey.appearance?.tabPosition)}
                >
                    {survey.appearance?.widgetLabel || ''}
                </button>
            )}
            {showSurvey && (
                <SurveyPopup
                    posthog={posthog}
                    survey={survey}
                    forceDisableHtml={forceDisableHtml}
                    style={styleOverrides}
                    onPopupSurveyDismissed={resetShowSurvey}
                    onCloseConfirmationMessage={resetShowSurvey}
                    surveyLanguage={surveyLanguage}
                />
            )}
        </Fragment>
    )
}

interface GetQuestionComponentProps extends CommonQuestionProps {
    question: SurveyQuestion
    displayQuestionIndex: number
}

const getQuestionComponent = ({
    question,
    forceDisableHtml,
    displayQuestionIndex,
    appearance,
    onSubmit,
    onPreviewSubmit,
    initialValue,
    canGoBack,
    onBack,
}: GetQuestionComponentProps): JSX.Element | null => {
    const baseProps = {
        forceDisableHtml,
        appearance,
        onPreviewSubmit: (res: string | string[] | number | null) => {
            onPreviewSubmit(res)
        },
        onSubmit: (res: string | string[] | number | null) => {
            onSubmit(res)
        },
        initialValue,
        displayQuestionIndex,
        canGoBack,
        onBack,
    }

    switch (question.type) {
        case SurveyQuestionType.Open:
            return <OpenTextQuestion {...baseProps} question={question} key={question.id} />
        case SurveyQuestionType.Link:
            return <LinkQuestion {...baseProps} question={question} key={question.id} />
        case SurveyQuestionType.Rating:
            return <RatingQuestion {...baseProps} question={question} key={question.id} />
        case SurveyQuestionType.SingleChoice:
        case SurveyQuestionType.MultipleChoice:
            return <MultipleChoiceQuestion {...baseProps} question={question} key={question.id} />
        default:
            logger.error(`Unsupported question type: ${(question as any).type}`)
            return null
    }
}
